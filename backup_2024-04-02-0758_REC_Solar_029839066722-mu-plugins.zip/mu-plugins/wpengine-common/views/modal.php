<?php
/**
 * Modal
 *
 * @package wpengine/common-mu-plugin
 */

?>
<!-- Modal -->
<div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-header">
		<img src="<?php echo esc_url( WPE_PLUGIN_URL ); ?>/images/ajax-loader.gif" class="modal-loading" />
		<h3 id="myModalLabel">Modal header</h3>
	</div>
	<div class="modal-body">
		<div id="progress" class="progress"></div>
		<div class="progress-label"></div>
		<div id="status"></div>
	</div>
	<div class="modal-footer">
		<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
	</div>
</div>
