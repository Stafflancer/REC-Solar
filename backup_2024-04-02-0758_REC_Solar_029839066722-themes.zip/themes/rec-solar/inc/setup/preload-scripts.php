<?php
/**
 * Preload styles and scripts.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Preload styles and scripts.
 *
 * @return void
 */
function preload_scripts() {
	?>
	<link rel="preconnect" href="https://p.typekit.net">
	<link rel="preconnect" href="https://use.typekit.net" crossorigin>
	<link rel="preload" href="https://use.typekit.net/af/9bc52f/00000000000000007735fe04/30/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&v=3" as="font" type="font/woff2" crossorigin>
	<link rel="preload" href="https://use.typekit.net/af/a0a470/00000000000000007735fe05/30/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&v=3" as="font" type="font/woff2" crossorigin>
	<link rel="stylesheet" href="https://use.typekit.net/rre8ccq.css">
	<link rel="preload" href="<?php echo esc_url( get_theme_file_uri( '/assets/css/vendor/bootstrap.min.css' ) ); ?>" as="style">
	<link rel="preload" href="<?php echo esc_url( get_theme_file_uri( '/assets/css/vendor/animate.min.css' ) ); ?>" as="style">
	<link rel="preload" href="<?php echo esc_url( get_theme_file_uri( '/assets/css/menus.css' ) ); ?>" as="style">
	<link rel="preload" href="<?php echo esc_url( get_theme_file_uri( '/assets/css/custom-main.css' ) ); ?>" as="style">
	<link rel="preload" href="<?php echo esc_url( home_url( '/wp-includes/js/jquery/jquery.min.js' ) ); ?>" as="script">
	<link rel="preload" href="<?php echo esc_url( get_theme_file_uri( '/assets/js/vendor/wow/wow.min.js' ) ); ?>" as="script">
	<link rel="preload" href="<?php echo esc_url( get_theme_file_uri( '/assets/js/main.js' ) ); ?>" as="script">
	<?php if ( is_front_page() && file_exists( get_theme_file_path( '/assets/images/placeholder-home-video.jpg' ) )) { ?>
		<link rel="preload" href="<?php echo esc_url( get_theme_file_uri( '/assets/images/placeholder-home-video.jpg' ) ); ?>" as="image">
	<?php
	}
}
add_action( 'wp_head', __NAMESPACE__ . '\preload_scripts', 1 );