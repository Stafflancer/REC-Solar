<?php
/**
 * Display the social links saved in the theme options page.
 *
 * @package bopper
 */

namespace BopDesign\bopper;
use function BopDesign\bopper\print_element;
/**
 * Display the social links saved in the customizer.
 *
 * @author BopDesign
 */
function print_address() {
	$address_title = get_field( 'address_title', 'option' );
	$address = get_field( 'address', 'option' );
	$phone = get_field( 'phone', 'option' );
	if ( ! empty( $address_title ) || ! empty( $address ) ) { ?>
		<div class="address"><?php
			// Heading.
			if ( $address_title ) :
				print_element( 'heading', [
					'text'  => $address_title,
					'level' => 5,
				]);
			endif;
			// Address.
			if ( $address ) :
				print_element( 'content', [
					'content'  => $address,
					'class' => 'address-content',
				]);
			endif; ?>		
		</div><?php
	}
}