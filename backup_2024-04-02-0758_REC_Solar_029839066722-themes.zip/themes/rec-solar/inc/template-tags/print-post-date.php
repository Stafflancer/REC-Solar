<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some functionality here could be replaced by core features.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Prints HTML with date information for the current post.
 *
 * @param array $args Configuration args.
 */
function print_post_date( $args = [] ) {
	// Set defaults.
	$defaults = [
		'date_text'   => esc_html__( 'Posted on', THEME_TEXT_DOMAIN ),
		'date_format' => get_option( 'date_format' ),
	];

	// Parse args.
	$args = wp_parse_args( $args, $defaults );
	?>
	<span class="posted-on">
		<!-- <a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark"> -->
			<time class="entry-date published" datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>"><?php echo esc_html( get_the_time( $args['date_format'] ) ); ?></time>
		<!-- </a> -->
	</span>
	<?php
}