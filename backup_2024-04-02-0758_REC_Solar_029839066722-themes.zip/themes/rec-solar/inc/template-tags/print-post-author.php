<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some functionality here could be replaced by core features.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Prints HTML with author information for the current post.
 *
 * @param array $args Configuration args.
 */
function print_post_author( $args = [] ) {
	// Set defaults.
	$defaults = [
		'author_text' => esc_html__( 'by', THEME_TEXT_DOMAIN ),
	];

	// Parse args.
	$args = wp_parse_args( $args, $defaults );
	?>
	<span class="post-author">
		<span class="author vcard">
			<!-- <a class="url fn n" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"> --><?php echo esc_html( get_the_author() ); ?><!-- </a> -->
		</span>
	</span>
	<?php
}