<?php
/**
 * Display the social links saved in the theme options page.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Display the social links saved in the customizer.
 *
 * @author BopDesign
 */
function print_form() {

	$subscribe_form = get_field('subscribe_form', 'option');
	if(!empty($subscribe_form['form'])){
		echo '<h5>'.$subscribe_form['heading'].'</h5>';
		echo '<p>'.$subscribe_form['content'].'</p>';
		echo '<div class="footer-form">';
		echo do_shortcode( '[gravityform id="' . $subscribe_form['form'] . '" title="false" description="false" ajax="true"]' );
		echo '</div>';
	}
	
}