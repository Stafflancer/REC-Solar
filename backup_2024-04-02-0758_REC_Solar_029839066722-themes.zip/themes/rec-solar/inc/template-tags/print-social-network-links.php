<?php
/**
 * Display the social links saved in the theme options page.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Display the social links saved in the customizer.
 *
 * @author BopDesign
 */
function print_social_network_links() {
	// Create an array of our social links for ease of setup.
	// Change the order of the networks in this array to change the output order.
	$social_networks = get_field( 'social_media', 'option' );

	if ( ! empty( $social_networks ) && is_array( $social_networks ) ) :
		$count = count( $social_networks );
		?>
		<ul class="d-flex social-icons menu">
			<?php
			$i = 1;
			// Loop through our networks array.
			foreach ( $social_networks as $network => $network_url ) :
				// Only display the list item if a URL is set.
				if ( ! empty( $network_url ) ) :
					$icon_wrapper_class = ' me-2 me-lg-3';

					if ( $count === $i ) {
						$icon_wrapper_class = '';
					}
					?>
					<li class="<?php echo esc_attr( $icon_wrapper_class ); ?>">
						<a href="<?php echo esc_url( $network_url ); ?>" class="social-icon d-flex align-items-center justify-content-center rounded-circle <?php echo esc_attr( $network ); ?>" target="_blank">
							<?php
							if($network == 'gmail'){
								echo '<svg xmlns="http://www.w3.org/2000/svg" width="34.862" height="24.912" viewBox="0 0 34.862 24.912">
								  <g id="Group_88915" data-name="Group 88915" transform="translate(1 1)">
								    <rect id="Rectangle_8207" data-name="Rectangle 8207" width="32.862" height="22.912" rx="3.281" fill="#72777c" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
								    <path id="Path_53693" data-name="Path 53693" d="M558.5,691.145l16.431-15.738,16.431,15.738Z" transform="translate(-558.503 -668.233)" fill="#72777c" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
								    <path id="Path_53694" data-name="Path 53694" d="M591.365,659.9,574.934,675.64,558.5,659.9Z" transform="translate(-558.503 -659.902)" fill="#72777c" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
								  </g>
								</svg>';
							}
							else if($network == 'linkedin'){
								echo '<svg xmlns="http://www.w3.org/2000/svg" width="26.852" height="30.002" viewBox="0 0 26.852 30.002">
								  <path id="Path_53688" data-name="Path 53688" d="M17.367,19.145H11.441v20.37h5.926Zm2.778,0v20.37H26.07V26.553l1.481-.926,1.481-.37a2.963,2.963,0,0,1,1.667.37l.741.741a2.222,2.222,0,0,1,.37.926V39.7h5.741V27.108a7.778,7.778,0,0,0-1.111-3.889,7.407,7.407,0,0,0-2.963-2.963,9.444,9.444,0,0,0-3.889-.926,7.593,7.593,0,0,0-3.889.741v-.926Zm-8.333-8.333A3.7,3.7,0,0,0,10.7,13.4,3.519,3.519,0,0,0,11.811,16,3.333,3.333,0,0,0,14.4,17.108a3.519,3.519,0,0,0,3.7-3.7A3.519,3.519,0,0,0,17,10.812,3.519,3.519,0,0,0,14.4,9.7a3.333,3.333,0,0,0-2.593,1.111" transform="translate(-10.7 -9.699)" fill="#72777c"/>
								</svg>';
							}
							else if($network == 'github'){
								echo '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>';
							}
							else{
								print_svg( [
									'icon'   => $network,
									'width'  => '24',
									'height' => '24',
								] ); 
							} ?>
							<span class="screen-reader-text">
								<?php
								/* translators: the social network name */
								printf( esc_attr__( 'Link to %s', THEME_TEXT_DOMAIN ), ucwords( esc_html( $network ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
								?>
							</span>
						</a><!-- .social-icon -->
					</li>
					<?php
					$i++;
				endif;
			endforeach;
			?>
		</ul><!-- .social-icons -->
	<?php endif;
}