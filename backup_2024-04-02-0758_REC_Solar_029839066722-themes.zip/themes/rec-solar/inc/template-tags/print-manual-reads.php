<?php
/**
 *  Display the most recent post type cards (but not the current one).
 *
 * @package bopper
 */

namespace BopDesign\bopper;

use WP_Query;

/**
 * Display the most recent post type cards (but not the current one).
 *
 * @param array  $exclude
 * @param string $post_type
 * @param int    $number_of_posts
 *
 * @return void
 */
function print_manual_reads( array $exclude = [], string $post_type = 'post', int $number_of_posts = 3 ) {
	//	$number_of_posts          = get_sub_field( 'number_of_posts' );
	$number_of_posts_to_query = is_int( $number_of_posts ) ? $number_of_posts + 1 : 3;

	$args = [
		'post_type'           => $post_type,
		'posts_per_page'      => $number_of_posts_to_query,
		'post_status'         => 'publish',
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	];

	$recent_posts = new WP_Query( $args );

	if ( $recent_posts->have_posts() ):
		$posts = 0; // count the posts displayed, up to $number_of_posts.

		if ( $number_of_posts > 3 ) {
			// Turn into slider only if there are enough items.
			wp_enqueue_style( 'swiperjs-style' );
			wp_enqueue_script( 'swiperjs-script' );

			$latest_reads_swiper = "
const manualReadSwiper = new Swiper('.manual-reads.swiper', {
	slidesPerView: 1,
	spaceBetween: 15,
	// Optional parameters
	loop: true,

	// If we need pagination
	pagination: {
		el: '.swiper-pagination',
		type: 'progressbar',
	},

	// Navigation arrows
	navigation: {
		nextEl: '.swiper-button-next',
		prevEl: '.swiper-button-prev',
	},

	// Responsive breakpoints
	breakpoints: {
		// when window width is >= 768px
		768: {
			slidesPerView: 2,
		},
		// when window width is >= 1024px
		1024: {
			slidesPerView: 3,
		},
		// when window width is >= 1200px
		1200: {
			slidesPerView: 3,
			spaceBetween: 30,
		}
	}
});
";
			wp_add_inline_script( 'swiperjs-script', $latest_reads_swiper );

			echo '<div class="swiper manual-reads">
					<div class="swiper-wrapper">';

			while ( $recent_posts->have_posts() && $posts < $number_of_posts ) :
				$recent_posts->the_post();
				$current = get_the_ID();

				if ( ! in_array( $current, $exclude ) ) {
					$posts++;
					echo '<div class="swiper-slide">';
					print_module( 'card-post', [] );
					echo '</div>';
				}
			endwhile;
			wp_reset_postdata();

			echo '</div>
				<div class="swiper-pagination swiper-pagination-progressbar"></div>
			</div>
			<div class="swiper-button-prev"></div>
			<div class="swiper-button-next"></div>';
		} else {
			$animation_delay = 0; // animation delay variable.

			echo '<div class="row row-cols-1 row-cols-md-3 g-4">';

			while ( $recent_posts->have_posts() && $posts < $number_of_posts ) :
				$recent_posts->the_post();
				$current = get_the_ID();

				if ( ! in_array( $current, $exclude ) ) {
					$posts++;
					echo '<div class="col wow animate__animated animate__fadeInUp" data-wow-delay="' . esc_attr( $animation_delay ) . 's">';
					print_module( 'card-post', [] );
					echo '</div>';
					$animation_delay += 0.25;
				}
			endwhile;
			wp_reset_postdata();

			echo '</div>';
		}
	endif;
}