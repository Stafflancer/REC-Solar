<?php
/**
 * Flush out the transients used in BopDesign\bopper\get_categorized_blog.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Flush out the transients used in BopDesign\bopper\get_categorized_blog.
 *
 * @return bool Whether transients were deleted.
 */
function category_transient_flusher() {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return false;
	}

	// Like, beat it. Dig?
	return delete_transient( 'bopper_categories' );
}

add_action( 'delete_category', __NAMESPACE__ . '\category_transient_flusher' );
add_action( 'save_post', __NAMESPACE__ . '\category_transient_flusher' );