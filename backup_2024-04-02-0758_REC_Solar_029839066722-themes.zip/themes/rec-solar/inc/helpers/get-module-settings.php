<?php
/**
 * Returns an array of module attributes from a block's Gutenberg fields and Display Options.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Returns a string of formatted container attributes.
 *
 * @param array $block           Array of block attributes.
 * @param array $display_options Array of Display Options attributes.
 *
 * @return array The array of classes.
 */
function get_module_settings( $block, $display_options ) {
	// Bail early, if the block is not provided.
	if ( empty( $block ) ) {
		return [];
	}

	// Get block display options.
	if ( empty( $display_options ) ) {
		$display_options = get_display_options( $block['id'] );
	}

	// Setup defaults.
	$module_defaults = [
		'align_text'     => 'aling-left',
		'align_content'  => 'top left',
		'container_size' => 'container', // container/container-fluid
		'column_size'  => 'full',  // auto | 4 - 11 | full
		'animation'      => 'none',  // none | animate.css classes (fadeIn | slideIn | zoomInUp | etc.)
	];
	$module_attributes    = [];

	if ( ! empty( $block['align_content'] ) ) {
		$module_attributes['align_content'] = $block['align_content'];
	}

	// Set the container width: container vs. container-fluid.
	if ( isset( $display_options['container_size'] ) && ! empty( $display_options['container_size'] ) ) {
		$module_attributes['container_size'] = esc_attr( $display_options['container_size'] );
	}

	// Set the content width: content vs. content-fluid.
	if ( isset( $display_options['column_size'] ) && ! empty( $display_options['column_size'] ) ) {
		$module_attributes['column_size'] = esc_attr( $display_options['column_size'] );
	}

	// Get animation class.
	if ( isset( $display_options['animation'] ) && ! empty( $display_options['animation'] ) ) {
		$module_attributes['animation'] = get_class_name_by_attribute( 'animation', esc_attr( $display_options['animation'] ) );
	}

	$module_attributes = wp_parse_args( $module_attributes, $module_defaults );

	foreach ( $module_attributes as $attr => $value ) {
		$module_settings[$attr] = get_class_name_by_attribute( $attr, $value );
	}

	return $module_settings;
}