<?php
/**
 * Returns an array of ACF fields.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Returns an array of ACF fields.
 *
 * @param int $block_id (optional) ID of the post or of the block ($block[id]).
 */
function get_design_options( $block_id = false ) {
	if ( ! function_exists( 'get_field' ) ) :
		return '';
	endif;

	$block_id      = $block_id ? $block_id : get_the_ID();
	$design_options = [];

	if ( $block_id ) {
		$design_options = get_field( 'design', $block_id );
	}
	
	return $design_options;
}