<?php
/**
 * Render block background options.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Render a module.
 *
 * @author BopDesign
 *
 * @param array  $design_options Array of Background Options.
 *
 * @return string|void
 */
function print_design_options( $design_options ) {
	if ( empty( $design_options ) ) {
		return '';
	}

	/**
	 * Setup background defaults.
	 */
	$background_defaults = [
		'class' => 'acf-block position-relative overflow-hidden',
	];

	$background_video_markup = $background_image_markup = $background_overlay_markup =  $background_pattern_markup = '';

	// Only try to get the rest of the settings if the background type is set to anything.
	if ( $design_options['background_type'] ) {
		if ( 'image' === $design_options['background_type'] ) {
			$background_image_id   = '';
			$background_image_size = 'full-width';

			if ( ! empty( $design_options['background_image'] ) ) {
				$background_image_id = $design_options['background_image']['ID'];
			}

			ob_start();
			$background_class = 'image-background d-block w-100 h-auto m-0 position-absolute top-0 bottom-0 start-0 end-0 object-center z-0';

			if ( ! empty( $design_options['has_parallax'] ) && $design_options['has_parallax'] ):
				$background_class .= ' bg-fixed bg-center bg-cover';
				$background_image_url = wp_get_attachment_image_url( $background_image_id, $background_image_size );
				?>
				<figure class="<?php echo esc_attr( $background_class ); ?>"
				        style="background-image:url(<?php echo $background_image_url; ?>);" aria-hidden="true"></figure>
			<?php else:
				?>
				<figure class="<?php echo esc_attr( $background_class ); ?>" aria-hidden="true">
					<?php echo wp_get_attachment_image( $background_image_id, $background_image_size, false, array( 'class' => 'w-100 h-100 object-cover' ) ); ?>
				</figure>
			<?php endif; ?>
			<?php
			$background_image_markup = ob_get_clean();
		}
		if ( 'video' === $design_options['background_type'] ) {
			if ( 'file' === $design_options['video_type'] && ! empty( $design_options['video_mp4'] ) || ! empty( $design_options['video_webm'] ) ) {
				$background_video = $design_options['video_mp4'];
				$video_webm = $design_options['video_webm'];
				$video_poster_attr = '';

				if ( is_front_page() && file_exists( get_theme_file_path( '/assets/images/placeholder-home-video.jpg' ) )) {
					$video_poster_attr = ' poster="' . get_theme_file_uri( '/assets/images/placeholder-home-video.jpg' ) . '"';
				}
				// Make sure videos stay in their containers - relative + overflow hidden.

				ob_start();
				?>
				<figure class="video-background d-block h-auto w-100 m-0 position-absolute top-0 bottom-0 start-0 end-0 object-top z-0">
					<video id="mp-video" autoplay muted playsinline loop
					       preload="none"<?php echo $video_poster_attr ?>>
						<?php if ( $background_video['url'] ) : ?>
							<source src="<?php echo esc_url( $background_video['url'] ); ?>" type="video/mp4">
						<?php endif; ?>
					</video>
					<video id="webm-video" autoplay muted playsinline loop
					       preload="none"<?php echo $video_poster_attr ?>>
						<?php if ( $video_webm['url'] ) : ?>
							<source src="<?php echo esc_url( $video_webm['url'] ); ?>" type="video/webm">
						<?php endif; ?>
					</video>
				</figure>
				<?php
				$background_video_markup = ob_get_clean();
			}

			if ( 'oembed' === $design_options['video_type'] && ! empty( $design_options['video_embed'] ) ) {
				$video_embed = $design_options['video_embed'];

				ob_start();
				// Use preg_match to find iframe src.
				preg_match('/src="(.+?)"/', $video_embed, $matches);
				$src = $matches[1];

				// Add extra parameters to src and replace HTML.
				$params = array(
				    'playsinline' => 1,
				    'controls'    => 0,
				    'hd'  => 1,
				    'autoplay' => 1,
				    'background' => 1,
				    'loop' => 1,
				    'byline' => 0,
				    'title' => 0,
				    'mute' => 1 
				);
				$new_src = add_query_arg($params, $src);
				$iframe = str_replace($src, $new_src, $video_embed);

				// Add extra attributes to iframe HTML.
				$attributes = 'frameborder="0"';
				$iframe = str_replace('></iframe>', ' ' . $attributes . '></iframe>', $iframe);

				// Display customized HTML. ?>
				<figure class="video-background d-block h-auto w-100 m-0 position-absolute top-0 bottom-0 start-0 end-0 object-top z-0">
					<?php echo $iframe; ?>
				</figure>
				<?php
				$background_video_markup = ob_get_clean();
			}

			if ( 'script' === $design_options['video_type'] && ! empty( $design_options['video_script'] ) ) {
				$video_script = $design_options['video_script'];
				$background_defaults['class'] .= ' has-background video-as-background position-relative overflow-hidden';

				ob_start(); ?>

				<div class="video-script video-background d-block h-auto w-100 m-0 position-absolute top-0 bottom-0 start-0 end-0 object-top z-0">
					<?php echo $video_script; ?>
				</div><?php
				$background_video_markup = ob_get_clean();
			}
		}
		if ( 'image' === $design_options['background_type'] || 'video' === $design_options['background_type']  && $design_options['has_overlay'] ) {

			if($design_options['overlay_type'] == 'color'){
				$overlay_class = 'position-absolute z-1 has-background-dim';
				$overlay_color = $design_options['overlay_color']['color_picker'];

				if ( '' !== $overlay_color ) {
					$overlay_class .= ' has-' . esc_attr( $overlay_color ) . '-background-color';
				}
			}
			else{
				$overlay_class = 'position-absolute z-1 has-background-dim gradient-overlay';
				$overlay_gradient = $design_options['overlay_gradient'];

				if ( '' !== $overlay_gradient ) {
					$overlay_class .= ' has-' . esc_attr( $overlay_gradient ) . '-gradient-color';
				}
			}
			ob_start();?>
			<span aria-hidden="true" class="<?php esc_attr_e( $overlay_class ); ?>"></span><?php
			if($design_options['overlay_filter'] == 1){
				if($design_options['overlay_type'] == 'color'){
				$overlay_color = $design_options['overlay_color']['color_picker'];
					if ( '' !== $overlay_color ) {
						$overlay_class_filter = 'position-absolute z-2 has-background-dim';
						$overlay_class_filter .= ' has-filter-' . esc_attr( $overlay_color ) . '-background-color';
					}
				}
				else{
					$overlay_class_filter = 'position-absolute z-2 has-background-dim filter-gradient-overlay';
					$overlay_gradient = $design_options['overlay_gradient'];

					if ( '' !== $overlay_gradient ) {
						$overlay_class_filter .= ' has-' . esc_attr( $overlay_gradient ) . '-gradient-color';
					}
				} ?>
				<span aria-hidden="true" class="<?php esc_attr_e( $overlay_class_filter ); ?>"></span><?php
			}
			$background_overlay_markup = ob_get_clean();
		}
		if ( 'gradient' === $design_options['background_type'] ) {
			$overlay_class = 'position-absolute z-1 has-background-dim gradient-overlay';
			$gradient = $design_options['gradient'];

			if ( '' !== $gradient ) {
				$overlay_class .= ' has-gradient-' . esc_attr( $gradient ) . '-background-color';
			}

			ob_start();
			?>
			<span aria-hidden="true" class="<?php esc_attr_e( $overlay_class ); ?>"></span>
			<?php
			$background_overlay_markup = ob_get_clean();
		}
		if ( $design_options['pattern'] == 1) {
			if ( $design_options['pattern_image']){
				ob_start();
				$pattern_image = $design_options['pattern_image'];
				$pattern_position = $design_options['pattern_position'];
				if(!empty($pattern_image) && !empty($pattern_image['url']))?>
				<div class="<?php echo "pattern-position-".$pattern_position; ?>">
					<figure class="has-pattern-show"><img src="<?php echo $pattern_image['url']; ?>"></figure>
				</div><?php
				$background_pattern_markup = ob_get_clean();
			}

		}
	}

	// If we have a background image, echo our background image markup inside the block container.
	if ( $background_image_markup ) {
		echo $background_image_markup; // WPCS XSS OK.
	}

	// If we have a background video, echo our background video markup inside the block container.
	if ( $background_video_markup ) {
		echo $background_video_markup; // WPCS XSS OK.
	}

	// If we have a pattern image and enable pattern option, echo our pattern image markup.
	if ( $background_pattern_markup ) {
		echo $background_pattern_markup; // WPCS XSS OK.
	}

	// If we have an overlay, echo our overlay markup inside the block container.
	if ( $background_overlay_markup ) {
		echo $background_overlay_markup; // WPCS XSS OK.
	}
}