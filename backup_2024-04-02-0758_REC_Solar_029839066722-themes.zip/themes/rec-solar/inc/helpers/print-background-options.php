<?php
/**
 * Render block background options.
 *
 * @package bopper
 */

namespace BopDesign\bopper;

/**
 * Render a module.
 *
 * @author BopDesign
 *
 * @param array  $background_options Array of Background Options.
 *
 * @return string|void
 */
function print_background_options( $background_options ) {
	if ( empty( $background_options ) ) {
		return '';
	}

	/**
	 * Setup background defaults.
	 */
	$background_defaults = [
		'class' => 'acf-block position-relative overflow-hidden',
	];

	$background_video_markup = $background_image_markup = $background_overlay_markup = $background_pattern_markup = '';

	// Only try to get the rest of the settings if the background type is set to anything.
	if ( $background_options['background_type'] ) {
		if ( 'image' === $background_options['background_type'] ) {
			$background_image_id   = '';
			$background_image_size = 'full-width';

			if ( ! empty( $background_options['background_image'] ) ) {
				$background_image_id = $background_options['background_image']['ID'];
			}

			ob_start();
			$background_class = 'image-background d-block w-100 h-auto m-0 position-absolute top-0 bottom-0 start-0 end-0 object-center z-0';

			if ( ! empty( $background_options['has_parallax'] ) && $background_options['has_parallax'] ):
				$background_class .= ' bg-fixed bg-center bg-cover';
				$background_image_url = wp_get_attachment_image_url( $background_image_id, $background_image_size );
				?>
				<figure class="<?php echo esc_attr( $background_class ); ?>"
				        style="background-image:url(<?php echo $background_image_url; ?>);" aria-hidden="true"></figure>
			<?php else:
				?>
				<figure class="<?php echo esc_attr( $background_class ); ?>" aria-hidden="true">
					<?php echo wp_get_attachment_image( $background_image_id, $background_image_size, false, array( 'class' => 'w-100 h-100 object-cover' ) ); ?>
				</figure>
			<?php endif; ?>
			<?php
			$background_image_markup = ob_get_clean();
		}

		if ( 'video' === $background_options['background_type'] ) {

			if ( 'file' === $background_options['video_type'] && ! empty( $background_options['video_mp4'] ) || ! empty( $background_options['video_webm'] ) ) {
				$background_video = $background_options['video_mp4'];
				$video_webm = $background_options['video_webm'];
				// Make sure videos stay in their containers - relative + overflow hidden.

				ob_start();
				?>
				<figure class="video-background d-block h-auto w-100 m-0 position-absolute top-0 bottom-0 start-0 end-0 object-top z-0">
					<video id="<?php echo esc_attr( $background_options['id'] ); ?>-video" autoplay muted playsinline loop
					       preload="none">
						<?php if ( $background_video['url'] ) : ?>
							<source src="<?php echo esc_url( $background_video['url'] ); ?>" type="video/mp4">
						<?php endif; ?>
					</video>
					<video id="<?php echo esc_attr( $background_options['id'] ); ?>-video" autoplay muted playsinline loop
					       preload="none">
						<?php if ( $video_webm['url'] ) : ?>
							<source src="<?php echo esc_url( $video_webm['url'] ); ?>" type="video/webm">
						<?php endif; ?>
					</video>
				</figure>
				<?php
				$background_video_markup = ob_get_clean();
			}

			if ( 'oembed' === $background_options['video_type'] && ! empty( $background_options['video_embed'] ) ) {
				$video_embed = $background_options['video_embed'];

				ob_start();
				// Use preg_match to find iframe src.
				preg_match('/src="(.+?)"/', $video_embed, $matches);
				$src = $matches[1];

				// Add extra parameters to src and replace HTML.
				$params = array(
				    'controls'  => 0,
				    'hd'        => 1,
				    'autohide'  => 1
				);
				$new_src = add_query_arg($params, $src);
				$iframe = str_replace($src, $new_src, $video_embed);

				// Add extra attributes to iframe HTML.
				$attributes = 'frameborder="0"';
				$iframe = str_replace('></iframe>', ' ' . $attributes . '></iframe>', $iframe);

				// Display customized HTML. ?>
				<figure class="video-background d-block h-auto w-100 m-0 position-absolute top-0 bottom-0 start-0 end-0 object-top z-0">
					<?php echo $iframe; ?>
				</figure><?php
				$background_video_markup = ob_get_clean();
			}

			if ( 'script' === $background_options['video_type'] && ! empty( $background_options['video_script'] ) ) {
				$video_script = $background_options['video_script'];
				$background_defaults['class'] .= ' has-background video-as-background position-relative overflow-hidden';

				ob_start(); ?>
				
				<div class="video-script video-background d-block h-auto w-100 m-0 position-absolute top-0 bottom-0 start-0 end-0 object-top z-0">
					<?php echo $video_script; ?>
				</div><?php
				$background_video_markup = ob_get_clean();
			}
		}

		if ( ( 'image' === $background_options['background_type'] || 'video' === $background_options['background_type'] ) && $background_options['has_overlay'] ) {
			$overlay_class = 'position-absolute z-1 has-background-dim';
			$overlay_color = $background_options['overlay_color']['color_picker'];

			if ( '' !== $overlay_color ) {
				$overlay_class .= ' has-' . esc_attr( $overlay_color ) . '-background-color';
			}
			if ( ! empty( $background_options['overlay_opacity'] ) && is_numeric( $background_options['overlay_opacity'] ) ) {
				$overlay_class .= ' has-background-dim-' . esc_attr( $background_options['overlay_opacity'] );
			}

			ob_start();
			?>
			<span aria-hidden="true" class="<?php esc_attr_e( $overlay_class ); ?>"></span>
			<?php
			$background_overlay_markup = ob_get_clean();
		}
		if ( 'gradient' === $background_options['background_type'] ) {
			$overlay_class = 'position-absolute z-1 has-background-dim gradient-overlay';
			$overlay_color = $background_options['overlay_color']['color_picker'];

			if ( '' !== $overlay_color ) {
				$overlay_class .= ' has-' . esc_attr( $overlay_color ) . '-background-color';
			}
			if ( ! empty( $background_options['overlay_opacity'] ) && is_numeric( $background_options['overlay_opacity'] ) ) {
				$overlay_class .= ' has-background-dim-' . esc_attr( $background_options['overlay_opacity'] );
			}

			ob_start();
			?>
			<span aria-hidden="true" class="<?php esc_attr_e( $overlay_class ); ?>"></span>
			<?php
			$background_overlay_markup = ob_get_clean();
		}
		if ( $background_options['has_pattern'] == 1) {
			if ( $background_options['pattern_image']){
				ob_start();
				$pattern_image = $background_options['pattern_image'];
				$pattern_position = $background_options['pattern_position']; 
				if(!empty($pattern_image) && !empty($pattern_image['url']))?>
				<div class="<?php echo "pattern-position-".$pattern_position; ?>">
					<figure class="has-pattern-show"><img src="<?php echo $pattern_image['url']; ?>"></figure>
				</div><?php 
				$background_pattern_markup = ob_get_clean();
			} 
			
		}
	}

	// If we have a background image, echo our background image markup inside the block container.
	if ( $background_image_markup ) {
		echo $background_image_markup; // WPCS XSS OK.
	}

	// If we have a background video, echo our background video markup inside the block container.
	if ( $background_video_markup ) {
		echo $background_video_markup; // WPCS XSS OK.
	}

	// If we have an overlay, echo our overlay markup inside the block container.
	if ( $background_overlay_markup ) {
		echo $background_overlay_markup; // WPCS XSS OK.
	}

	// If we have a pattern image and enable pattern option, echo our pattern image markup.
	if ( $background_pattern_markup ) {
		echo $background_pattern_markup; // WPCS XSS OK.
	}
}