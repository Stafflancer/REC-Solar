<?php
/**
 * ELEMENT: Button
 * Displays the theme button.
 *
 * Elements are analogous to 'Atoms' in Brad Frost's Atomic Design Methodology.
 *
 * @link https://atomicdesign.bradfrost.com/chapter-2/#atoms
 *
 * @package bopper
 */

use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\print_svg;

$element_defaults = [
	'class'         => [ 'acf-element', 'acf-element-button'],
	'id'            => '',
	'title'         => false,
	'url'           => false,
	'target'        => false,
	'type'          => false,
	'style'         => 'fill', // fill, outline.
	'icon'          => [],
	'icon_position' => 'after', // before, after.
	'role'          => '',
	'aria'          => [
		'controls' => '',
		'disabled' => false,
		'expanded' => false,
		'label'    => false,
		'current'  => '',
	],
];

$element_args = get_formatted_args( $args, $element_defaults );

if(!empty($element_args['button']['button_link']['title'])) :
	// Make sure element should render.
	if ( ! empty( $element_args['icon'] ) ) :
		$element_args['class'][] = 'icon';
		$element_args['class'][] = 'icon-' . $element_args['icon_position'];
	endif;
	$class = array();
	if ( ! empty( $args['button']['button_color']['color_picker'] ) && 'fill' === $args['button']['button_style'] ) {

		$class[] = 'has-background'.' '.'has-' . esc_attr( $args['button']['button_color']['color_picker'] ) . '-background-color ';
	}

	if ( ! empty( $args['button']['button_color']['color_picker'] ) && 'outline' === $args['button']['button_style'] ) {

		$class[] = 'has-background'.' '.'has-outline-' . esc_attr( $args['button']['button_color']['color_picker'] ) . '-color ';
	}

	if ( ! empty( $args['button']['button_text_color']['color_picker'] ) ) {

		$class[] = 'has-color-' . esc_attr( $args['button']['button_text_color']['color_picker'] );
	}	 ?>
	<div class="acf-module acf-module-buttons-group d-flex is-layout-flex">
		<div class="is-style-<?php echo esc_attr( $element_args['button']['style'] ); ?>">
			<a href="<?php echo $element_args['button']['button_link']['url']; ?>" class="acf-element acf-element-button <?php echo implode(" ", $class); ?>">
			<?php
			if ( $element_args['button']['button_link']['title'] ) :
				echo $element_args['button']['button_link']['title'];
			endif;

			if ( ! empty( $element_args['icon'] ) ) :
				print_svg( $element_args['icon'] );
			endif; ?>
			</<?php echo $element_args['button']['button_link']['url'] ? 'a' : 'button'; ?>>
		</div>
	</div><?php 
endif;
if ( $element_args['title'] || $element_args['icon'] ) :
	// Make sure element should render.
	if ( $element_args['title'] || $element_args['icon'] ) :
		if ( ! empty( $element_args['icon'] ) ) :
			$element_args['class'][] = 'icon';
			$element_args['class'][] = 'icon-' . $element_args['icon_position'];
		endif;

		// Set up element attributes.
		$element_atts = get_formatted_atts( [ 'id', 'href', 'target', 'class', 'type', 'aria', 'role' ], $element_args );
		?>
		<div class="is-style-<?php echo esc_attr( $element_args['style'] ); ?>">
			<<?php echo $element_args['href'] ? 'a' : 'button'; ?> <?php echo $element_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
				<?php
				if ( $element_args['title'] ) :
					echo $element_args['title'];
				endif;

				if ( ! empty( $element_args['icon'] ) ) :
					print_svg( $element_args['icon'] );
				endif;
				?>
			</<?php echo $element_args['href'] ? 'a' : 'button'; ?>>
		</div><?php 
	endif;
endif; ?>