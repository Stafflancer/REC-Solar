<?php
/**
 * The template for displaying blog posts. Page set as page for posts in Reading section.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package bopper
 */

get_header();

use function BopDesign\bopper\get_main_classes;

$post_id = is_home() ? get_option( 'page_for_posts' ) : get_the_ID();
?>
	<main id="main" class="<?php echo esc_attr( get_main_classes( [ 'template-blog', 'home-php' ] ) ); ?>" role="main">
		<div class="entry-content">
			<?php
			$post    = get_post( $post_id );
			$content = apply_filters( 'the_content', $post->post_content );

			echo $content;
			?>
		</div>
	</main><!-- #main -->
<?php
get_footer();
