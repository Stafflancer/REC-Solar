<?php /* Template Name: Contact */
get_header(); ?>

<?php the_content(); ?>

<?php
get_footer(); ?>