<?php /* Template name: Terms of Service */

get_header();

use function BopDesign\bopper\get_main_classes;

?>

	<main id="main" class="<?php echo esc_attr( get_main_classes( [] ) ); ?>" role="main">
		<div class="top-bg-img"></div>
		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'page' );
		endwhile; // End of the loop.
		?>
	</main><!-- #main -->

<?php
get_footer();