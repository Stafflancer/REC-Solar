<?php
/**
 * The template for displaying 404 pages (not found).
 * @package bopper
 */

get_header();

use function BopDesign\bopper\get_main_classes;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_global_design_options;
use function BopDesign\bopper\print_element;

$template = get_field('page_404_template', 'option');
$heading = $template['heading'];
$content = $template['content'];
$buttons = $template['buttons'];
$image = $template['image'];
$display_options = $template['display_options'];

if ( ! empty( $heading ) ||  empty( $content ) || ! empty( $buttons ) || ! empty( $image ) ) : 
	$class_name = array();
	$container_class  = array();
	$block_classes    = array();
	$background_image = '';
	if ( ! empty( $display_options['design']['background_image'] ) ) {
		$background_image = ' has-background image-as-background';
	}

	if ( ! empty( $display_options['design']['text_color'] ) ) {
		$block_classes[] = 'has-text-' . $display_options['design']['text_color']['color_picker'] . '-color ';
	}

	if ( ! empty( $display_options['design']['tagline_color'] ) ) {
		$block_classes[] = 'has-tagline-' . $display_options['design']['tagline_color']['color_picker'] . '-color ';
	}

	if ( ! empty( $display_options['design']['heading_color'] ) ) {
		$block_classes[] = 'has-heading-' . $display_options['design']['heading_color']['color_picker'] . '-color ';
	}

	if ( ! empty( $display_options['design']['background_color']['color_picker'] ) ) {
		$block_classes[] = 'has-background ';
		$block_classes[] = 'has-' . $display_options['design']['background_color']['color_picker'] . '-background-color ';
	}

	if ( $display_options['design']['container_size'] ) {
		$container_classes = ' position-relative z-10 inner-container';
		$container_class[] = esc_attr( $display_options['design']['container_size'] ) . $container_classes;
	}

	if ( $display_options['design']['column_size'] ) {
		$container_class[] = 'w-' . $display_options['design']['column_size'];
	}

	if ( $display_options['design']['margin_top'] == 'extra-small' ) {
		$class_name[] = 'margin-top-extra-small';
	} elseif ( $display_options['design']['margin_top'] == 'small' ) {
		$class_name[] = 'margin-top-small';
	} elseif ( $display_options['design']['margin_top'] == 'medium' ) {
		$class_name[] = 'margin-top-medium';
	} elseif ( $display_options['design']['margin_top'] == 'large' ) {
		$class_name[] = 'margin-top-large';
	} elseif ( $display_options['design']['margin_top'] == 'extra-large' ) {
		$class_name[] = 'margin-top-extra-large';
	} else {
		$class_name[] = 'mt-0';
	}

	if ( $display_options['design']['margin_bottom'] == 'extra-small' ) {
		$class_name[] = 'margin-top-extra-small';
	} elseif ( $display_options['design']['margin_bottom'] == 'small' ) {
		$class_name[] = 'margin-top-small';
	} elseif ( $display_options['design']['margin_bottom'] == 'medium' ) {
		$class_name[] = 'margin-top-medium';
	} elseif ( $display_options['design']['margin_bottom'] == 'large' ) {
		$class_name[] = 'margin-top-large';
	} elseif ( $display_options['design']['margin_bottom'] == 'extra-large' ) {
		$class_name[] = 'margin-top-extra-large';
	} else {
		$class_name[] = 'mt-0';
	}

	if ( $display_options['design']['padding_top'] == 'extra-small' ) {
		$class_name[] = 'margin-top-extra-small';
	} elseif ( $display_options['design']['padding_top'] == 'small' ) {
		$class_name[] = 'padding-top-small';
	} elseif ( $display_options['design']['padding_top'] == 'medium' ) {
		$class_name[] = 'padding-top-medium';
	} elseif ( $display_options['design']['padding_top'] == 'large' ) {
		$class_name[] = 'padding-top-large';
	} elseif ( $display_options['design']['padding_top'] == 'extra-large' ) {
		$class_name[] = 'padding-top-extra-large';
	} else {
		$class_name[] = '';
	}

	if ( $display_options['design']['padding_bottom'] == 'extra-small' ) {
		$class_name[] = 'padding-bottom-extra-small';
	} elseif ( $display_options['design']['padding_bottom'] == 'small' ) {
		$class_name[] = 'padding-bottom-small';
	} elseif ( $display_options['design']['padding_bottom'] == 'medium' ) {
		$class_name[] = 'padding-bottom-medium';
	} elseif ( $display_options['design']['padding_bottom'] == 'large' ) {
		$class_name[] = 'padding-bottom-large';
	} elseif ( $display_options['design']['padding_bottom'] == 'extra-large' ) {
		$class_name[] = 'padding-bottom-extra-large';
	} else {
		$class_name[] = '';
	}
	$column_class = join( ' ', [
		'col-md-10 col-sm-10',
	] ); ?>
	<main id="main" class="<?php echo esc_attr( get_main_classes( [] ) ); ?>" role="main">
		<section
			class="acf-block error-main position-relative <?php echo implode( ' ', $block_classes ) . ' ' . $background_image . ' alignfull  ' . implode( ' ', $class_name ); ?>">
			<?php print_global_design_options( $display_options ); ?>
			<div class="<?php echo implode( ' ', $container_class ); ?>">
				<div class="error-main-grid">
					<div class="error-main-leftcontentblock">
						<?php
						if ( $heading ) :
							$heading["level"] = 1;
							print_module('heading-tagline',[
								$heading
							]);
						endif; 
						if ( $content  ) :
							print_element( 'content', [
								'content'  => $content
							] );
						endif; 
						if ( $buttons ) :
							$buttons['class'] = [ 'common-btn', 'mt-0' ];
							print_module( 'buttons-group', $buttons );
						endif; ?>
					</div>
					<div class="error-main-rightimgblock">
						<div class="error-image"><?php
							$image_class = 'img-top-way';
							if ( ! empty( $image ) ) :
								echo wp_get_attachment_image( $image, 'full', array( 'class' => esc_attr( $image_class ) ) ); 
							else : ?>
								<img class="<?php echo esc_attr( $image_class ); ?>" src="<?php echo get_theme_file_uri( '/assets/images/placeholder-square.jpg' ); ?>" alt="Image Placeholder" width="764" height="764" aria-hidden="true"><?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</section>
	</main>
<?php
endif;

get_footer();