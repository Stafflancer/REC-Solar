<?php
/**
 * Search & Filter Pro
 *
 * Sample Results Template
 *
 * @package   Search_Filter
 * @author    Ross Morsali
 * @link      https://searchandfilter.com
 * @copyright 2018 Search & Filter
 *
 * Note: these templates are not full page templates, rather
 * just an encapsulation of the results loop which should
 * be inserted in to other pages by using a shortcode - think
 * of it as a template part
 *
 * This template is an absolute base example showing you what
 * you can do, for more customisation see the WordPress docs
 * and using template tags -
 *
 * http://codex.wordpress.org/Template_Tags
 *
 */

use function BopDesign\bopper\print_module;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $post;
$post_slug = $post->post_name;
$paged     = ! empty( $_GET['sf_paged'] ) ? $_GET['sf_paged'] : 1;

if ( $query->have_posts() ) {
	?>
	<div id="results-list" class="container new-press-index">
		<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 gx-4 gy-4 justify-content-center">
			<?php
			while ( $query->have_posts() ) {
				$query->the_post();
				print_module( 'news-press-post', [] );
			}
			?>
		</div>
	</div>
	<?php if ( $query->max_num_pages > 1 ) { ?>
		<div class="pagination-set">
			<div class="pagination-bottom d-flex justify-content-center pagination">
				<?php
				echo paginate_links( [
					'prev_text' => "previous",
					'next_text' => "next",
					'base'      => site_url() . '%_%',
					'format'    => "?paged=%#%",
					'total'     => $query->max_num_pages,
					'current'   => $paged,
					'mid_size'  => 1,
					'end_size'  => 0,
				] );
				?>
			</div>
		</div>
		<?php
	}
	wp_reset_postdata();
	?>
<?php } else { ?>
	<div class="nothing-found">
		<h2>Nothing Found!</h2>
	</div>
<?php } ?>