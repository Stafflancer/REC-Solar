<?php
/**
 * MODULE: Columns with Icon
 *
 * Modules are analogous to 'Molecules' in Brad Frost's Atomic Design Methodology.
 *
 * @link    https://atomicdesign.bradfrost.com/chapter-2/#molecules
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;

$module_defaults = [
	'class'   => [
		'acf-module',
		'acf-module-columns-with-icon',
		'card position-relative',
		'h-100',
		'',
		'',
		'',
		'has-background-background-color',
	],
	'icon'    => false,
	'heading' => false,
	'content' => false,
	'link'  => false,
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );

$image_class = 'card-img-top w-100 h-100 object-cover object-center';
?>
<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<?php if ( ! empty( $module_args['icon'] ) ) : ?>
		<figure class="columns-with-icon-img">
			<?php echo wp_get_attachment_image( $module_args['icon'], 'thumbnail', array( 'class' => esc_attr( $image_class ) ) ); ?>
		</figure>
	<?php endif; ?>
	<div class="card-body"><?php
		// Heading.
		echo '<h4>'.$module_args['heading'].'</h4>';

		// Content.
		if ( $module_args['content'] ) :
			print_element( 'content', [
				'content' => $module_args['content'],
			] );
		endif;
		if ( $module_args['link'] ) : ?>
			<div class="card-footer"><?php
				print_element(
					'anchor',
					[
						'text' => $module_args['link']['title'],
						'href' => $module_args['link']['url'],
						'target' => $module_args['link']['target'],
					]
				); ?>
			</div><?php
		endif; ?>
	</div>
</div>