<?php
/**
 * MODULE: Simple Text Columns
 *
 * Modules are analogous to 'Molecules' in Brad Frost's Atomic Design Methodology.
 *
 * @link https://atomicdesign.bradfrost.com/chapter-2/#molecules
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;

$module_defaults = [
	'class'      => [ 'acf-module', 'acf-module-simple-text-columns' ],
	'icon'    => false,
	'heading'    => false,
	'content'    => false,
	'button' => false,
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );
$image_class = 'card-img-top w-100 h-100 object-cover object-center';
?>
<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<?php if ( ! empty( $module_args['icon'] ) ) : ?>
		<figure class="card-icon-img">
			<?php echo wp_get_attachment_image( $module_args['icon'], 'large', array( 'class' => esc_attr( $image_class ) ) ); ?>
		</figure>
	<?php endif; ?>
	<div class="card-content">
		<div class="card-content-inner">
			<?php

			// Heading.
			if ( $module_args['heading'] ) :
				print_element(
					'heading',
					[
						'text'  => $module_args['heading'],
						'level' => 3,
						'class' => 'h4',
					]
				);
			endif;

			// Content.
			if ( $module_args['content'] ) :
				print_element(
					'content',
					[
						'content' => $module_args['content'],
						'class'   => '',
					]
				);
			endif;?>
		</div><?php
		//button
		if ( $module_args['button'] ) :
			print_element( 'button', [
				'button' => $module_args['button'],
			] );
		endif; ?>
	</div>
</div>