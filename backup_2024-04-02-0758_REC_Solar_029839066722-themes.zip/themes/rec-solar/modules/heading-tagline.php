<?php
/**
 * ELEMENT: Heading & Tagline
 *
 * Elements are analogous to 'Atoms' in Brad Frost's Atomic Design Methodology.
 *
 * @link https://atomicdesign.bradfrost.com/chapter-2/#atoms
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;

$module_defaults  = [
	'class' => [ 'acf-element', 'acf-element-heading' ],
	'tagline'    => false,
	'tagline_color'    => false,
	'main_heading'    => false,
	'heading_color'    => false,
	'add_arrow'    => false,
	'level' => false,
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );


//if ( !empty($module_args['main_heading'] ) || !empty($module_args['tagline'] ) ) : 
	$add_arrow = '';
	if($module_args[0]['add_arrow'] == 1) :
		$add_arrow = 'add-heading-arrow';
	else :
		$add_arrow = 'no-heading-arrow';
	endif;
	$tagline_color = '';
	if(!empty($module_args[0]['tagline_color'])) :
		$tagline_color = 'has-'.$module_args[0]['tagline_color']['color_picker'].'-background-color';
	endif;
	if(!empty($module_args[0]['heading_color'])) :
		$heading_color = 'has-'.$module_args[0]['heading_color']['color_picker'].'-background-color';
	endif;  ?>
	<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
		<div class="section-header-inner"><?php
				// Tagline.
				if ( $module_args[0]['tagline'] ) :
					echo '<div class="header-section-tagline">';
						print_element(
						'tagline',
							[
								'text'  => $module_args[0]['tagline'],
								'level' => 5,
								'class' => $tagline_color,
							]
						);
					echo '</div>';
				endif;
				// Heading.
				if ( $module_args[0]['main_heading'] ) :
					echo '<div class="header-section-heading">';
						print_element(
							'heading',
							[
								'text'  => $module_args[0]['main_heading'],
								'level' => $module_args[0]['level'],
								'class' => $add_arrow.' '.$heading_color,
							]
						);
					echo '</div>';
				endif; ?>
		</div>
	</div><?php
//endif; 