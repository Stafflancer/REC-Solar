<?php
/**
 * MODULE: Open Position
 *
 * Modules are analogous to 'Molecules' in Brad Frost's Atomic Design Methodology.
 *
 * @link https://atomicdesign.bradfrost.com/chapter-2/#molecules
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\get_trimmed_excerpt;

$module_defaults = [
	'class'      => [ 'acf-module', 'acf-module-postcard' ],
	'image'    => get_post_thumbnail_id(),
	'heading' => get_the_title(),
	'location' => get_field('location', get_the_ID()),
	'time_type' => get_field('time_type', get_the_ID()),
	'link' => get_the_permalink(),
	'excerpt' => get_trimmed_excerpt( [ 'post' => get_the_ID() ] ),
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );

$location = get_the_terms( get_the_ID(), 'location' ); ?>


<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<div class="job-opening-row"><?php
		if ( $module_args['heading'] ) :
			print_element( 'heading', [
				'text'  => $module_args['heading'],
				'level' => 4,
			]);
		endif; ?>
		<div class="location-job"><?php
			if ( $module_args['location'] ) :
					print_element( 'heading', [
						'text'  => $module_args['location'],
						'level' => 4,
						'class' => [ 'card-title', 'h4' ],
				] );
			endif; 
			if ( $module_args['time_type'] ) :
				echo '<label>'.$module_args['time_type'].'</label>';
			endif; ?>
		</div>
		<div class="card-links">
			<div class="is-style-fill"><?php
				print_element( 'anchor', [
					'text'  => 'Submit Resume',
					'href'  => get_the_permalink(),
					'class' => 'has-white-color has-chestnut-red-to-halloween-orange-to-faded-orange-gradient-background has-text-color has-background wp-element-button',
				] ); ?>
			</div>
		</div>
	</div>
</div>