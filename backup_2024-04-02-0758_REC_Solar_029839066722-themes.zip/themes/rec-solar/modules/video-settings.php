<?php
/**
 * MODULE: Video Settings 
 *
 * Modules are analogous to 'Molecules' in Brad Frost's Atomic Design Methodology.
 *
 * @link    https://atomicdesign.bradfrost.com/chapter-2/#molecules
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;

$module_defaults = [
	'class'      => [ 'acf-module', 'acf-module-video', '' ],
	'video_setting' =>  false,
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );

$image_class = 'video-top w-100 h-100';

?>

<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<?php if ( $module_args[0]['video_setting'] ) :
	preg_match( '/src="(.+?)"/', $module_args[0]['video_setting'], $matches );
	$src = $matches[1]; ?>
	<div class="video-outer">
		<?php
		// Add extra parameters to src and replace HTML.
		$params  = array(
			'controls'  => 1,
		    'hd'        => 1,
		    'autohide'  => 1
		);
		$new_src = add_query_arg( $params, $src );
		$iframe  = str_replace( $src, $new_src, $module_args[0]['video_setting'] );

		// Add extra attributes to iframe HTML.
		$attributes = 'frameborder="0"';
		$iframe     = str_replace( '></iframe>', ' ' . $attributes . '></iframe>', $iframe );

		// Display customized HTML.
		echo $iframe;
		?>
	</div><?php 
endif; ?>
</div>
