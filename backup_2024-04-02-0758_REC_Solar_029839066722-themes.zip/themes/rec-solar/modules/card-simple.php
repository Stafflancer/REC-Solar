<?php
/**
 * MODULE: Simple Card
 *
 * Modules are analogous to 'Molecules' in Brad Frost's Atomic Design Methodology.
 *
 * @link https://atomicdesign.bradfrost.com/chapter-2/#molecules
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;

$module_defaults = [
	'class'      => [ 'acf-module', 'acf-module-card-simple' ],
	'heading'    => false,
	'content'    => false,
	'link' => false,
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );

?>
<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<div class="card-content">
		<?php

		// Heading.
		if ( $module_args['heading'] ) :
			print_element(
				'heading',
				[
					'text'  => $module_args['heading'],
					'level' => 3,
				]
			);
		endif;

		// Content.
		if ( $module_args['content'] ) :
			print_element(
				'content',
				[
					'content' => $module_args['content'],
					'class'   => '',
				]
			);
		endif; ?>
	</div><?php
	// Link.
	if ( $module_args['link'] ) : ?>
		<div class="card-footer"><?php
			print_element(
				'anchor',
				[
					'text' => $module_args['link']['title'],
					'href' => $module_args['link']['url'],
					'target' => $module_args['link']['target'],
				]
			); ?>
		</div><?php
	endif; ?>
</div>