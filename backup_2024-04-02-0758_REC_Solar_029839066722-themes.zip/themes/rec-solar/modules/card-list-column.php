<?php
/**
 * MODULE: List Column
 *
 * Modules are analogous to 'Molecules' in Brad Frost's Atomic Design Methodology.
 *
 * @link    https://atomicdesign.bradfrost.com/chapter-2/#molecules
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;

$module_defaults = [
	'class'   => [
		'acf-module',
		'acf-module-list-column',
		'card position-relative d-flex overflow-hidden',
		'h-100',
		'',
		'text-break',
		'',
		'has-background-background-color',
	],
	'icon'    => false,
	'tagline'    => false,
	'heading' => false,
	'content' => false,
	'link'    => false,
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );

$image_class = 'card-img-top w-100 h-100 object-cover object-center';
?>
<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<?php if ( ! empty( $module_args['icon'] ) ) : ?>
		<figure class="check-mark-icon rounded-circle d-flex align-items-center justify-content-center">
			<?php echo wp_get_attachment_image( $module_args['icon'], 'thumbnail', array( 'class' => esc_attr( $image_class ) ) ); ?>
		</figure>
	<?php endif; ?>
	<div class="card-body"><?php
		// Tagline.
		if ( $module_args['tagline'] ) :
			print_element(
				'tagline',
					[
						'text'  => $module_args['tagline'],
						'level' => 5,
					]
				);
		endif;
		// Heading.
		if ( $module_args['heading'] ) :
			print_element( 'heading', [
				'text'  => $module_args['heading'],
				'level' => 4,
				'class' => [ 'card-title', 'h5', 'text-uppercase' ],
			] );
		endif;

		// Content.
		if ( $module_args['content'] ) :
			print_element( 'content', [
				'content' => $module_args['content'],
			] );
		endif;
		// Link.
		if ( $module_args['link'] ) : ?>
			<div class="card-footer"><?php
				print_element(
					'anchor',
					[
						'text' => $module_args['link']['title'],
						'href' => $module_args['link']['url'],
						'target' => $module_args['link']['target'],
					]
				); ?>
			</div><?php
		endif; ?>
	</div>
</div>