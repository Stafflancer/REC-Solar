<?php
/**
 * MODULE: Card - Blog
 * Template part for displaying reusable card in blocks and archives.
 *
 * Modules are analogous to 'Molecules' in Brad Frost's Atomic Design Methodology.
 *
 * @link    https://atomicdesign.bradfrost.com/chapter-2/#molecules
 *
 * @package bopper
 */

use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_formatted_atts;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\get_trimmed_excerpt;

$module_defaults = [
	'class'   => [
		'acf-module',
		'acf-module-card-transparent',
		'col',
		'card-blog-post',
		'hover-image-zoom',
		'has-background-color',
		'position-relative',
	],
	'image'   => get_post_thumbnail_id(),
	'heading' => get_the_title(),
	'excerpt' => get_trimmed_excerpt( [ 'post' => get_the_ID() ] ),
	'button'  => [
		'title'  => 'View',
		'url'    => get_the_permalink(),
		'target' => false,
		'class'  => [ 'stretched-link' ],
	],
];

$module_args = get_formatted_args( $args, $module_defaults );

// Set up element attributes.
$module_atts = get_formatted_atts( [ 'class' ], $module_args );

$image_class = 'card-img-top';

$news_type = get_the_terms( get_the_ID(), 'category' );

$news_type_terms = join( ' | ', wp_list_pluck( $news_type, 'name' ) );

$anchor_class = $module_args['button']['class'];
$anchor_class[] = 'd-flex align-items-center flex-row-reverse text-uppercase';

wp_enqueue_style( 'news-press-card-style', get_theme_file_uri( '/assets/css/modules/news-press-post.css' ), [], null );
?>
<div <?php echo $module_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<div class="card-body h-100 flex-direction-column justify-content-between">
		<div class="card-text">
			<?php if ( ! empty( $news_type_terms ) ) { ?>
				<span class="label"><?php echo $news_type_terms; ?></span>
			<?php } ?>
			<?php
			// Heading.
			if ( $module_args['heading'] ) :
				print_element( 'heading', [
					'text'  => $module_args['heading'],
					'level' => 4,
					'class' => [ 'card-title', 'h4' ],
				] );
			endif;
			?>
		</div>
		<div class="card-links d-flex justify-content-end w-100">
			<?php
			print_element( 'anchor', [
				'text'  => $module_args['button']['title'],
				'href'  => $module_args['button']['url'],
				'class' => $anchor_class,
			] );
			?>
		</div>
	</div>
</div>