<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package bopper
 */

use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-5XBD20R14K"></script>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());

		gtag('config', 'G-5XBD20R14K');
	</script>
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'site-wrapper no-js' ); ?>>
	<?php wp_body_open(); ?>

	<a class="skip-link screen-reader-text" href="#main"><?php esc_html_e( 'Skip to content', THEME_TEXT_DOMAIN ); ?></a>
	<?php
	$notification_bar = get_field( 'notification_bar', 'option' );
	$site_logo        = get_field( 'site_logo', 'option' );
	$wrapper_classes  = 'site-header w-100';
	$wrapper_classes  .= $site_logo ? ' has-logo' : '';
	$wrapper_classes  .= has_nav_menu( 'primary' ) || has_nav_menu( 'mobile' ) ? ' has-menu' : '';

	if ( ! empty( $notification_bar['message'] ) ) {
		?>
		<div class="header-top-bar">
			<div class="header-top-inner">
				<?php
				print_element( 'anchor', [
					'text'  => $notification_bar['message']['title'],
					'href'  => $notification_bar['message']['url'],
					'class' => 'top-a-bar',
				] );
				?>
				<button type="button" class="btn-close header-bar-close" aria-label="Close">
					<svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19">
						<line x1="0.35" y1="0.35" x2="18.65" y2="18.65" fill="none" stroke="#fff" stroke-width="1"/>
						<line x1="18.65" y1="0.35" x2="0.35" y2="18.65" fill="none" stroke="#fff" stroke-width="1"/>
					</svg>
				</button>
			</div>
		</div>
	<?php } ?>
	<header id="masthead" class="<?php echo esc_attr( $wrapper_classes ); ?> main-header" role="banner">
		<div class="container position-relative">
			<div class="row align-items-center">
				<div class="col-9 col-lg-3">
					<div class="site-branding header-logo">
						<?php if ( $site_logo ) : ?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
								<img src="<?php echo wp_get_attachment_image_url( $site_logo, 'medium' ); ?>" class="logo" width="177" height="51" alt="Go back to home page"/>
							</a>
						<?php else: ?>
							<p class="site-title">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
							</p>
						<?php endif; ?>
					</div><!-- .site-branding -->
				</div>

				<div class="col-3 col-lg-9">
					<?php if ( has_nav_menu( 'primary' ) || has_nav_menu( 'mobile' ) ) : ?>
						<button type="button" class="off-canvas-open bar-icon d-block d-lg-none" aria-expanded="false" aria-label="<?php esc_attr_e( 'Open Menu', THEME_TEXT_DOMAIN ); ?>">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					<?php endif; ?>
					<div class="header-navigation-outer">
						<nav id="site-navigation" class="main-navigation navigation-menu d-none d-lg-flex justify-content-end align-items-center" aria-label="<?php esc_attr_e( 'Main Navigation', THEME_TEXT_DOMAIN ); ?>">
							<?php
									wp_nav_menu(
									array(
										'theme_location' => 'primary',
										'menu_id'        => 'primary-menu',
									)
								);

							/*if ( is_front_page() ) {
								wp_nav_menu( [
									'theme_location' => 'primary',
									'menu_id'        => 'primary-menu',
									'menu_class'     => 'menu dropdown d-flex justify-content-end',

								] );
							} else {
								wp_nav_menu( [
									'menu'        => 'Primary Link Menu',
									'menu_id'     => 'privacy-menu',
									'menu_class'  => 'menu dropdown d-flex justify-content-end',
									'container'   => false,
									'fallback_cb' => false,
								] );
							}*/
							?>
							<div class="d-flex align-items-center">
								<?php
								$buttons = get_field( 'header_buttons', 'option' );
								if ( $buttons ) :
									$buttons['class'] = [ 'common-btn' ];
									print_module( 'buttons-group', $buttons );
								endif;

								$links = get_field( 'links', 'option' );
								if ( $links ):
									?>
									<div class="header-links">
										<?php
										foreach ( $links as $link ) :
											$link_url   = $link['link']['url'];
											$link_title = $link['link']['title'];

											echo '<a href="' . $link_url . '">' . $link_title . '</a>';
										endforeach;
										?>
									</div>
								<?php endif; ?>
							</div>
						</nav><!-- #site-navigation -->
					</div>
				</div>
			</div>
		</div><!-- .container -->
	</header><!-- #masthead -->