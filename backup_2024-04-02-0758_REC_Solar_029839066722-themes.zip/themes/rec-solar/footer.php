<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package bopper
 */

use function BopDesign\bopper\print_copyright_text;
use function BopDesign\bopper\print_social_media;
use function BopDesign\bopper\print_mobile_menu;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_address;

$enable_gradient_separator = get_field('enable_gradient_separator','option'); 
if($enable_gradient_separator == 1){ ?><div class="enable-gradient-separator"></div><?php } ?>
<footer id="colophon" class="site-footer" role="contentinfo">
	<div class="container">
		<div class="row">
			<div class="col-12 col-md-6 col-lg-6">
				<div class="footer-logos">
					<?php
					$logo = get_field( 'logo', 'option' ); 
					if ( ! empty( $logo ) ) : ?>
							<div class="footer-logo">
								<?php echo wp_get_attachment_image( $logo, 'full' );?>
							</div><?php
					endif; ?>
					<div class="footer-address">
						<?php print_address();  ?>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-6"><div class="rightblock-footer"><?php
				$phone = get_field( 'phone', 'option' ); 
				if ( ! empty( $phone ) ) : ?>
					<div class="footer-contact">
						<a href="<?php echo esc_url( $phone['url'] ); ?>"  target="<?php echo esc_attr( $phone['target'] ); ?>">
							<?php echo esc_html( $phone['title'] ); ?>
						</a>
					</div><?php 
				endif; ?>
				<div class="social-menu footer-social">
					<?php print_social_media(); ?>
				</div></div>
			</div>
		</div>
		<div class="footermenu-middle">
			<div class="row">
				<?php if ( has_nav_menu( 'footer' ) ) : ?>
					<div class="col-sm-12 col-md-12 col-lg-12">
						<nav id="site-footer-navigation" class="footer-navigation" aria-label="<?php esc_attr_e( 'Footer Navigation', THEME_TEXT_DOMAIN ); ?>">
							<ul id="footer-menu" class="footer-menu menu">
								<?php
								wp_nav_menu(
									array(
										'theme_location' => 'footer',
										'items_wrap'     => '%3$s',
										'container'      => false,
										'link_before'    => '<span>',
										'link_after'     => '</span>',
										'fallback_cb'    => false,
									)
								);
								?>
							</ul>
						</nav>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<div class="copy-right-top">
			<div class="row justify-content-center">
				<div class="col-md-8 col-sm-12 align-self-center">
					<div class="site-info has-color-white text-center">
						<?php print_copyright_text(); ?>
					</div>
				</div>
				
			</div>
		</div>
	</footer><!-- #colophon -->

	<?php print_mobile_menu(); ?>
	<?php wp_footer(); ?>
</body>
</html>