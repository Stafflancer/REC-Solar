<?php
/**
 * Template part for displaying posts.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package bopper
 */
use function BopDesign\bopper\print_post_date;
use function BopDesign\bopper\print_post_author;
use function BopDesign\bopper\print_post_thumbnail;
use function BopDesign\bopper\print_entry_footer;
global $current_user;
$author_id = $post->post_author
?>

<article id="post-<?php the_ID(); ?>">
	<div class="single-news-outer">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12">
					<div class="single-news-inner">
						<div class="breadcrumb">
							<ul class="breadcrumb-inner">
								<?php bcn_display(); ?>
							</ul>
						</div>
						<header class="entry-header"><?php
							if ( is_singular() ) :
								the_title( '<h1 class="entry-title">', '</h1>' );
							else :
								the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
							endif; ?>
							<div class="entry-meta d-flex align-items-center justify-content-between blog-detail">
								<div class="date-author">
									<img src="<?php echo esc_url( get_avatar_url( $author_id ) ); ?>" />
									<span><?php echo get_the_date('M d, Y'); ?></span> |
									<a href="<?php echo get_author_posts_url($author_id); ?>"><?php the_author(); ?></a>
								  </div>
							</div><!-- .entry-meta -->
						</header><!-- .entry-header -->

						<?php print_post_thumbnail(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="single-news-text detail-first-paragraph">
		<div class="entry-content">
			<?php
			the_content(
				sprintf(
					wp_kses(
					/* translators: %s: Name of current post. Only visible to screen readers */
						esc_html__( 'Continue reading %s <span class="meta-nav">&rarr;</span>', THEME_TEXT_DOMAIN ),
						[
							'span' => [
								'class' => [],
							],
						]
					),
					the_title( '<span class="screen-reader-text">"', '"</span>', false )
				)
			);

			wp_link_pages(
				[
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', THEME_TEXT_DOMAIN ),
					'after'  => '</div>',
				]
			);
			?>
		</div><!-- .entry-content -->
	</div>
</article><!-- #post-<?php the_ID(); ?> -->