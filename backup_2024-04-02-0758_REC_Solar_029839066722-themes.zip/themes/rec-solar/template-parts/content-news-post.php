<?php
/**
 * Template part for displaying news post.
 *
 * @link    https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package bopper
 */

use function BopDesign\bopper\print_post_date;
use function BopDesign\bopper\print_module;

$categories = get_the_terms( get_the_ID(), 'news-type' );
$exclude    = get_the_ID();

if ( $categories ) {
	$category_id = array();
	foreach ( $categories as $category ) {
		$category_id[] = $category->term_id;
	}
}
?>
<section class="add-to-any-social">
	<?php echo do_shortcode( '[addtoany]' ); ?>
</section>
<article id="post-<?php the_ID(); ?>">
	<div class="single-news-outer single-post-main-outer">
		<div class="top-bg-img"></div>
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-12 col-lg-11">
					<div class="single-news-inner">
						<?php
						$index_pages = get_field( 'index_pages', 'option' );
						$news        = $index_pages['news'];
						if ( $news ) {
							?>
							<div class="news-backbtn">
								<a href="<?php echo esc_attr( $news ); ?>">
									<svg xmlns="http://www.w3.org/2000/svg" width="22.205" height="19.143" viewBox="0 0 22.205 19.143">
										<path d="M19.547,2.658l-14.817,6.913,14.817,6.914" fill="none" stroke="#24b34b"
										      stroke-linecap="round" stroke-width="4"/>
									</svg>
									<span class="post-tagline"><?php _e( 'News', THEME_TEXT_DOMAIN ); ?></span>
								</a>
							</div>
						<?php } ?>
						<div class="single-resource-profile podcast-re">
							<div class="intro"><?php
								if ( is_singular() ) :
									the_title( '<h1 class="entry-title">', '</h1>' );
								else :
									the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
								endif; ?>
							</div>
						</div>
						<div class="single-post-date">
							<div class="row align-items-center">
								<div class="col-12 col-md-6 col-sm-6">
									<div class="has-color-dark-gray text-uppercase font-size-small letter-sap">
										<span class="pe-2"><?php print_post_date(); ?></span>
										<span>|</span>
										<span class="ps-2"><?php the_author(); ?></span>
									</div>
								</div>
								<div class="col-12 col-md-6 col-sm-6 text-md-end text-sm-end has-color-gray font-size-small">
									<?php echo do_shortcode( '[rt_reading_time label="Reading Time:" postfix="minutes" postfix_singular="minute"]' ); ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="single-news-text single-post-text-data">
		<div class="entry-content">
			<?php
			the_content( sprintf( wp_kses( /* translators: %s: Name of current post. Only visible to screen readers */ esc_html__( 'Continue reading %s <span class="meta-nav">&rarr;</span>', THEME_TEXT_DOMAIN ), [
				'span' => [
					'class' => [],
				],
			] ), the_title( '<span class="screen-reader-text">"', '"</span>', false ) ) );

			wp_link_pages( [
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', THEME_TEXT_DOMAIN ),
				'after'  => '</div>',
			] ); ?>
		</div><!-- .entry-content -->
		<!-- Pagination -->
	</div>
	<?php
	$heading = get_field( 'rel_heading', 'option' );
	$content = get_field( 'rel_content', 'option' );
	$form    = get_field( 'rel_form', 'option' );

	if ( $heading || $content || $form ) :
		wp_enqueue_style( 'cta-subscribe', get_theme_file_uri( '/blocks/cta-subscribe/cta-subscribe.css' ) );
		wp_enqueue_style( 'swiperjs-style' );
		wp_enqueue_script( 'swiperjs-script' );

		$latest_post_slider = "
let swiper = new Swiper('.latest-post-slider', {
	loop: false,
	slidesPerView: 3,
	spaceBetween: 25,
	watchSlidesProgress: true,
	breakpoints: {
		1024: {
			slidesPerView: 3,
		},
		768: {
			slidesPerView: 2,
		},
		480: {
			slidesPerView: 1,
		},
		320: {
			slidesPerView: 1,
		}
	},
	on: {
		init: function () {
			const slidesCount = this.slides.length;
			const slidesPerView = this.params.slidesPerView;

			if (slidesCount <= slidesPerView) {
				this.el.classList.add('less-than-slides-per-view');
			}
		}
	},
	navigation: {
		nextEl: '.next',
		prevEl: '.prev',
	},
});
";
		wp_add_inline_script( 'swiperjs-script', $latest_post_slider );
		?>
		<section class="acf-block main-related-posts hero-banner cta-subscribe position-relative overflow-hidden has-text--color has-tagline--color has-heading-white-color has-background gradient-as-background has-horizontal-main-background-gradient alignfull mt-0 mb-0 padding-top-medium padding-bottom-medium">
			<span class="position-absolute z-1 has-background-dim gradient-overlay has-gradient-horizontal-main-background-color" aria-hidden="true"></span>
			<div class="container z-9 w-12">
				<?php
				$news        = array(
					'category__in'        => $category_id,
					'posts_per_page'      => 3,
					'post_status'         => 'publish',
					'ignore_sticky_posts' => true,
					'no_found_rows'       => true,
					'post__not_in'        => array( $exclude ),
				);
				$latest_news = get_posts( $news );
				if ( ! empty( $latest_news ) ) :
					?>
					<div class="related-block-row">
						<h2 class="related-heading acf-element acf-element-heading text-uppercase">Related Reads</h2>
						<div class="slider-arrow-outer">
							<div class="swiper latest-post-slider">
								<div class="swiper-wrapper">
									<?php
									global $post;
									foreach ( $latest_news as $post ) :
										setup_postdata( $post );
										echo '<div class="swiper-slide">';
										print_module( 'news-press-post', [] );
										echo '</div>';
									endforeach;
									wp_reset_postdata();
									?>
								</div>
							</div>
							<div class="slider-arrows">
								<a href="javascript:" class="arrowbtn prev">
									<svg xmlns="http://www.w3.org/2000/svg" width="22.205" height="19.143" viewBox="0 0 22.205 19.143">
										<path d="M19.547,2.658l-14.817,6.913,14.817,6.914" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="4"/>
									</svg>
								</a>
								<a href="javascript:" class="arrowbtn next">
									<svg xmlns="http://www.w3.org/2000/svg" width="22.205" height="19.143" viewBox="0 0 22.205 19.143">
										<path d="M2.658,2.658l14.817,6.913-14.817,6.914" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="4"/>
									</svg>
								</a>
							</div>
						</div>
					</div>
				<?php endif; ?>
				<div class="cta-form-row">
					<div class="cta-form-inner">
						<div class="text-box">
							<?php if ( $heading || $content ) { ?>
								<div class="text-box-inner">
									<h3 class="acf-element acf-element-heading"><?php echo $heading; ?></h3>
									<div
										class="acf-element acf-element-content card-text post-excerpt m-0"><?php echo $content; ?>
									</div>
								</div>
							<?php } ?>
						</div>
						<?php if ( $form ) { ?>
							<div class="cta-form-box">
								<?php echo $form; //do_shortcode( '[gravityform id="' . $form . '" title="false" description="false" ajax="true"]' ); ?>
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
		</section>
	<?php endif; ?>
</article><!-- #post-<?php the_ID(); ?> -->