<?php
/**
 * Template part for displaying team member.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package bopper
 */

use function BopDesign\bopper\print_post_date;
use function BopDesign\bopper\print_post_author;
use function BopDesign\bopper\print_post_thumbnail;
use function BopDesign\bopper\print_entry_footer;
use function BopDesign\bopper\print_element; 
use function BopDesign\bopper\print_module; 
use function BopDesign\bopper\print_global_design_options; 
use function BopDesign\bopper\print_global_team_design_options;

?>
<article class="team-memberdetails" id="post-<?php the_ID(); ?>">
	<div class="single-post-main-outer">
		<div class="top-bg-img"></div>
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-10 col-12">
					<div class="single-team-inner"><?php 
					$index_pages = get_field('index_pages', 'option');
					$team_member = $index_pages['team_member'];
					if($team_member){ ?>
						<div class="news-backbtn">
							<a href="<?php echo esc_attr( $team_member ); ?>">
								<svg xmlns="http://www.w3.org/2000/svg" width="22.205" height="19.143" viewBox="0 0 22.205 19.143">
									<path id="Path_66471" data-name="Path 66471" d="M-7103.254,3811l-14.817,6.913,14.817,6.914" transform="translate(7122.801 -3808.342)" fill="none" stroke="#24b34b" stroke-linecap="round" stroke-width="4"/>
								</svg>
								<span class="post-tagline"><?php _e( 'Leadership', THEME_TEXT_DOMAIN ); ?></span>
							</a>
						</div><?php 
					} ?>	
					</div>
					<div class="teamcontent-main">
						<div class="teamimg"><?php
						if(has_post_thumbnail()){ ?>
							<img src="<?php echo get_the_post_thumbnail_url(); ?>" /><?php
						} else { ?>
							<img src="<?php echo get_theme_file_uri( '/assets/images/placeholder-square.jpg' ); ?>" /><?php
						} ?>
						</div>
						<div class="teamcontent-block">
							<div class="intro"><?php
									if ( is_singular() ) :
										the_title( '<h1 class="entry-title">', '</h1>' );
									else :
										the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
									endif; ?>
							</div><?php 
							$role = get_field('title', get_the_ID()); 
							if($role) { ?>
								<div class="role"><?php
									echo $role; ?>
								</div><?php 
							} ?>
							<div class="entry-content">
								<?php
								the_content(
									sprintf(
										wp_kses(
										/* translators: %s: Name of current post. Only visible to screen readers */
											esc_html__( 'Continue reading %s <span class="meta-nav">&rarr;</span>', THEME_TEXT_DOMAIN ),
											[
												'span' => [
													'class' => [],
												],
											]
										),
										the_title( '<span class="screen-reader-text">"', '"</span>', false )
									)
								);

								wp_link_pages(
									[
										'before' => '<div class="page-links">' . esc_html__( 'Pages:', THEME_TEXT_DOMAIN ),
										'after'  => '</div>',
									]
								); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php 
	$heading = get_field( 'heading_cr', 'option' );
	$content = get_field( 'content_cr', 'option' );
	$buttons = get_field( 'buttons_cr', 'option' );
	$display_options = get_field( 'display_options', 'option' );
	if ( ! empty( $heading ) ||  empty( $content ) || ! empty( $buttons ) || ! empty( $display_options ) ) : 
		wp_enqueue_style( 'cta-buttons', get_theme_file_uri( '/blocks/cta-buttons/cta-buttons.css' ) );
		$class_name = array();
		$container_class  = array();
		$block_classes    = array();
		$background_image = '';
		if ( ! empty( $display_options['design']['background_image'] ) ) {
			$background_image = ' has-background image-as-background';
		}

		if ( ! empty( $display_options['design']['text_color'] ) ) {
			$block_classes[] = 'has-text-' . $display_options['design']['text_color']['color_picker'] . '-color ';
		}

		if ( ! empty( $display_options['design']['tagline_color'] ) ) {
			$block_classes[] = 'has-tagline-' . $display_options['design']['tagline_color']['color_picker'] . '-color ';
		}

		if ( ! empty( $display_options['design']['heading_color'] ) ) {
			$block_classes[] = 'has-heading-' . $display_options['design']['heading_color']['color_picker'] . '-color ';
		}

		if ( ! empty( $display_options['design']['background_color']['color_picker'] ) ) {
			$block_classes[] = 'has-background ';
			$block_classes[] = 'has-' . $display_options['design']['background_color']['color_picker'] . '-background-color ';
		}

		if ( $display_options['design']['container_size'] ) {
			$container_classes = ' position-relative z-10 inner-container';
			$container_class[] = esc_attr( $display_options['design']['container_size'] ) . $container_classes;
		}

		if ( $display_options['design']['column_size'] ) {
			$container_class[] = 'w-' . $display_options['design']['column_size'];
		}

		if ( $display_options['design']['margin_top'] == 'extra-small' ) {
			$class_name[] = 'margin-top-extra-small';
		} elseif ( $display_options['design']['margin_top'] == 'small' ) {
			$class_name[] = 'margin-top-small';
		} elseif ( $display_options['design']['margin_top'] == 'medium' ) {
			$class_name[] = 'margin-top-medium';
		} elseif ( $display_options['design']['margin_top'] == 'large' ) {
			$class_name[] = 'margin-top-large';
		} elseif ( $display_options['design']['margin_top'] == 'extra-large' ) {
			$class_name[] = 'margin-top-extra-large';
		} else {
			$class_name[] = 'mt-0';
		}

		if ( $display_options['design']['margin_bottom'] == 'extra-small' ) {
			$class_name[] = 'margin-top-extra-small';
		} elseif ( $display_options['design']['margin_bottom'] == 'small' ) {
			$class_name[] = 'margin-top-small';
		} elseif ( $display_options['design']['margin_bottom'] == 'medium' ) {
			$class_name[] = 'margin-top-medium';
		} elseif ( $display_options['design']['margin_bottom'] == 'large' ) {
			$class_name[] = 'margin-top-large';
		} elseif ( $display_options['design']['margin_bottom'] == 'extra-large' ) {
			$class_name[] = 'margin-top-extra-large';
		} else {
			$class_name[] = 'mt-0';
		}

		if ( $display_options['design']['padding_top'] == 'extra-small' ) {
			$class_name[] = 'margin-top-extra-small';
		} elseif ( $display_options['design']['padding_top'] == 'small' ) {
			$class_name[] = 'padding-top-small';
		} elseif ( $display_options['design']['padding_top'] == 'medium' ) {
			$class_name[] = 'padding-top-medium';
		} elseif ( $display_options['design']['padding_top'] == 'large' ) {
			$class_name[] = 'padding-top-large';
		} elseif ( $display_options['design']['padding_top'] == 'extra-large' ) {
			$class_name[] = 'padding-top-extra-large';
		} else {
			$class_name[] = '';
		}

		if ( $display_options['design']['padding_bottom'] == 'extra-small' ) {
			$class_name[] = 'padding-bottom-extra-small';
		} elseif ( $display_options['design']['padding_bottom'] == 'small' ) {
			$class_name[] = 'padding-bottom-small';
		} elseif ( $display_options['design']['padding_bottom'] == 'medium' ) {
			$class_name[] = 'padding-bottom-medium';
		} elseif ( $display_options['design']['padding_bottom'] == 'large' ) {
			$class_name[] = 'padding-bottom-large';
		} elseif ( $display_options['design']['padding_bottom'] == 'extra-large' ) {
			$class_name[] = 'padding-bottom-extra-large';
		} else {
			$class_name[] = '';
		}
		$column_class = join( ' ', [
			'col-md-10 col-sm-10',
		] ); ?>
		<section class="acf-block cta-buttons position-relative overflow-hidden <?php echo implode( ' ', $block_classes ) . ' ' . $background_image . ' alignfull  ' . implode( ' ', $class_name ); ?>">
			<?php print_global_design_options( $display_options ); ?>	
			<div class="<?php echo implode( ' ', $container_class ); ?>">
				<div class="row  justify-content-center">
					<div class="col-12 col-md-12 col-sm-12">
						<div class="cta-buttons-inner heading-center">	
							<?php
							if ( $heading ) :
								$heading["level"] = 2;
								print_module('heading-tagline',[
									$heading
								]);
							endif; 
							if ( $content  ) :
								print_element( 'content', [
									'content'  => $content
								] );
							endif; 
							if ( $buttons ) :
								print_module( 'buttons-group', $buttons );
							endif; ?>
						</div>
					</div>
				</div>
			</div>
		</section><?php 
	endif; ?>
</article><!-- #post-<?php the_ID(); ?> -->