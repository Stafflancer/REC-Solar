<?php
/**
 * BLOCK: CTA - Side Form
 *
 * @param array        $block      The block settings and attributes.
 * @param string       $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'cta-side-form-' . $block['id'],
	'class'    => [ 'acf-block', 'cta', 'cta-side-form', 'position-relative', 'overflow-hidden' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start text-left',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'content',
	'form',
], $block['id'] );

if ( ! empty( $design_options['column_size'] ) ) :
	$column_size_class = 'col-12 col-md-' . $design_options['column_size'] . ' col-sm-' . $design_options['column_size'];
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	$column_size_class,
	'z-9',
] );

$row_class = join( ' ', [
	'row',
] );

if ( ! empty( $block_content['content'] ) || ! empty( $block_content['form'] ) ) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<div class="<?php echo esc_attr( $row_class ); ?> justify-content-between">
				<?php if ( $block_content['content']['heading'] || $block_content['content']['content'] ) : ?>
					<div class="col-12 col-md-5">
						<div class="cta-form-main-text">
							<?php
							// Heading.
							if ( $block_content['content']['heading'] ) :
								print_element( 'heading', [
									'text'  => $block_content['content']['heading'],
									'level' => $block_content['content']['heading_type']['value'],
								] );
							endif;

							// Content.
							if ( $block_content['content']['content'] ) :
								print_element( 'content', [
									'content' => $block_content['content']['content'],
								] );
							endif;
							?>
						</div>
					</div>
				<?php
				endif;
				// Form.
				if ( $block_content['form'] ) :
					?>
					<div class="col-12 col-md-6" data-wow-delay="0.25s">
						<div class="cta-form-main">
							<?php echo $block_content['form']; ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</section>
<?php endif; ?>