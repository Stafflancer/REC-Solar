<?php
/**
 * BLOCK: Hero Banner - Featured Posts With Image
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\get_trimmed_excerpt;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'hero-banner-featured-posts-with-image-' . $block['id'],
	'class'    => [ 'acf-block', 'hero-banner-featured-posts-with-image', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative',
		'align_text'     => 'text-start text-left',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'display_breadcrumbs',
	'heading',
	'content',
	'featured_posts',
	'buttons',
], $block['id'] );

if(!empty($design_options['column_size'])) :
	$column_size_class = 'col-12 col-md-'.$design_options['column_size'].' col-sm-'.$design_options['column_size'].'';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	'z-9',
] );

$row_class    = join( ' ', [
	'row ',
] );
$column_class    = join( ' ', [
	$column_size_class,
] ); 

if ( !empty($block_content['heading']) || !empty($block_content['content']) || !empty($block_content['featured_posts']) || !empty($block_content['buttons']) ) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<div class="<?php echo esc_attr( $row_class ); ?> justify-content-between">
				<div class="<?php echo esc_attr( $column_class ); ?>">
					<div class="<?php echo esc_attr( $row_class ); ?> justify-content-between">
						<div class="col-lg-5 col-md-6 col-sm-12"><?php
							if(! empty( $block_content['heading'] ) || ! empty( $block_content['content'] ) || !empty($block_content['buttons'])  ) : ?>
								<div class="section-header-outer"><?php
									if ( ! empty( $block_content['display_breadcrumbs'] ) ) { ?>
										<div class="breadcrumb">
											<ul class="breadcrumb-inner">
												<?php bcn_display(); ?>
											</ul>
										</div><?php
									} 
									print_element(
									'tagline',
										[
											'text'  => get_the_title(),
										]
									); 
									if ( $block_content['heading'] ) : ?>
										<div class="header-section-heading"><?php
											// Heading.
											print_element( 'heading', [
												'text'  => $block_content['heading'],
												'level' => 1,
											] ); ?>
										</div><?php
									endif;
									// Content.
									if ( $block_content['content'] ) :
										print_element(
											'content',
											[
												'content' => $block_content['content'],
											]
										);
									endif; 

									// buttons
									if ( $block_content['buttons'] ) :
										$buttons = $block_content['buttons'];
										$buttons['class'] = [ 'cta-btn' ];
										print_module(
											'buttons-group',
											$buttons
										);
									endif; ?>
								</div><?php
							endif;  ?>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-12">
							<?php
							if ( ! empty( $block_content['featured_posts'] ) ) : 
								global $post; ?>
								<div class="section-header-after-sec">
									<div class="swiper slider-hero-banner-featured-image">
										<div class="swiper-wrapper"><?php
											foreach ( $block_content['featured_posts'] as $post ):
												setup_postdata( $post );
												$image = get_post_thumbnail_id(); ?>
												<div class="swiper-slide">
													<div class="acf-module-card-transparent">
														<label>FEATURED</label>
														<div class="card-inner">
															<div class="imgblock">
															<figure class="slider-card-img">
																<?php if ( ! empty( $image ) ) : ?>
																	<?php echo wp_get_attachment_image( $image, 'large' ); ?>
																<?php else: ?>
																	<img src="<?php echo get_theme_file_uri( '/assets/images/placeholder-square.jpg' ); ?>" alt="Image Placeholder" width="764" height="764" aria-hidden="true">
																<?php endif; ?>
															</figure></div>
															<div class="headblock"><?php
															// Heading.
															if ( get_the_title() ) :
																print_element( 'heading', [
																	'text'  => get_the_title(),
																	'level' => 3,
																	'class' => [ 'card-title', 'h4' ],
																] );
															endif; ?></div>
														</div>
														<div class="card-footer">
															<?php
															print_element( 'anchor', [
																'text'  => 'View',
																'href'  => get_the_permalink(),
																'class' => 'featured-posts-btn',
															] ); ?>
														</div>
													</div>
												</div><?php
											endforeach; ?>
										</div>
										<div class="swiper-pagination"></div>
									</div>
								</div><?php
							endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>