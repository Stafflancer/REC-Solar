<?php
/**
 * BLOCK: Search & Filter Shortcodes
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_module;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'search-filter-shortcode-' . $block['id'],
	'class'    => [ 'acf-block', 'search-filter', 'search-filter-shortcode', 'position-relative', 'overflow-hidden' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'heading',
	'content',
	'filter_shortcode',
	'results_shortcode',
], $block['id'] );

if ( ! empty( $design_options['column_size'] ) ) :
	$column_size_class = 'col-12 col-md-' . $design_options['column_size'] . ' col-sm-' . $design_options['column_size'] . '';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	$column_size_class,
	'z-9',
] );
$row_class       = join( ' ', [
	'row ',
] );
$column_class    = join( ' ', [
	'search-filter-shortcode-inner',
] );

if ( ! empty( $block_content['heading'] ) || ! empty( $block_content['content'] ) || ! empty( $block_content['filter_shortcode'] ) || ! empty( $block_content['results_shortcode'] ) ) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<div class="<?php echo esc_attr( $row_class ); ?>"><?php
			if ( !empty($block_content['heading']) || !empty($block_content['content'])) : ?>
				<div class="col-12">
					<div class="filter-head">
						<?php
						// Heading.
						if ( $block_content['heading'] ) :
							print_element( 'heading', [
								'text'  => $block_content['heading'],
								'level' => 1,
							] );
						endif;

						// Content.
						if ( $block_content['content'] ) :
							print_element( 'content', [
								'content' => $block_content['content'],
							] );
						endif;
						?>
					</div>
				</div><?php
			endif; ?>
				<div class="<?php echo esc_attr( $column_class ); ?>">
					<div id="shortcode-results" class="shortcode-box-outer">
						<?php if ( ! empty( $block_content['filter_shortcode'] ) ) { ?>
							<div class="shortcode-filter">
								<div class="shortcode-filter-inner">
									<?php echo $block_content['filter_shortcode']; ?>
								</div>
							</div>
						<?php } ?>
						<?php if ( ! empty( $block_content['results_shortcode'] ) ) { ?>
							<div class="shortcode-result">
								<?php echo $block_content['results_shortcode']; ?>
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>