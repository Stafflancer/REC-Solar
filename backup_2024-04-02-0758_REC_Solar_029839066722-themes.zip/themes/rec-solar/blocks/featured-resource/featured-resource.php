<?php
/**
 * BLOCK: Featured Resource
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'featured-resource-' . $block['id'],
	'class'    => [ 'acf-block', 'featured-resource', 'position-relative', 'overflow-hidden' ],
	'settings' => [
		'container_size' => 'container position-relative',
		'align_text'     => 'text-start text-left',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'resource'
], $block['id'] );

if ( ! empty( $design_options['column_size'] ) ) :
	$column_size_class = 'col-12 col-md-' . $design_options['column_size'] . ' col-sm-' . $design_options['column_size'] . '';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	'z-9',
] );

$row_class    = join( ' ', [
	'row ',
] );
$column_class = join( ' ', [
	$column_size_class,
] );

if ( ! empty( $block_content['resource'] ) ) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<?php
			if ( ! empty( $block_content['resource'] ) ) :
				global $post;
				?>
				<div class="<?php echo esc_attr( $row_class ); ?>">
					<div class="<?php echo esc_attr( $column_class ); ?>">
						<div class="section-header-after-sec">
							<div class="swiper featured-resource-slider">
								<div class="swiper-wrapper">
									<?php
									foreach ( $block_content['resource'] as $post ):
										setup_postdata( $post );
										$image = get_post_thumbnail_id( get_the_ID() ); ?>
										<div class="swiper-slide downloads-box">
											<div class="downloads-boxblock">
												<div class="box-inner-left">
													<figure class="slider-transparent-img">
														<?php
														if ( ! empty( $image ) ) :
															$image_class = 'resource-image';
															?>
															<?php echo wp_get_attachment_image( $image, 'full', array( 'class' => esc_attr( $image_class ) ) ); ?>
														<?php else: ?>
															<img class="<?php echo esc_attr( $image_class ); ?>" src="<?php echo get_theme_file_uri( '/assets/images/placeholder-square.jpg' ); ?>" alt="" width="764" height="764" aria-hidden="true">
														<?php endif; ?>
													</figure>
												</div>
												<div class="box-inner-right">
													<?php
													// tagline.
														print_element( 'tagline', [
															'text'  => 'Featured Resource',
														] );

													// Heading.
													if ( get_the_title() ) :
														print_element( 'heading', [
															'text'  => get_the_title(),
															'level' => 3,
															'class' => [ 'card-title', 'h4' ],
														] );
													endif;

													// Content.
													if ( get_the_content() ) :
														print_element( 'content', [
															'content' => get_the_excerpt(),
															'class'   => [ 'post-excerpt', 'm-0' ],
														] );
													endif;

													print_element( 'anchor', [
														'text'  => 'VIEW',
														'href'  => get_the_permalink(),
														'class' => 'acf-element acf-element-button has-background has-secondary-background-color has-color-black',
													] );
													?>
												</div>
											</div>
										</div>
									<?php endforeach; ?>
								</div>
								<div class="swiper-pagination"></div>
							</div>
						</div>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</section>
<?php endif; ?>