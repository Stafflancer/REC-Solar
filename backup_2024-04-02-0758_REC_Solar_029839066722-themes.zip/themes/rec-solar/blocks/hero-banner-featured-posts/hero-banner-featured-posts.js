var sliderHeroBannerFeatured = new Swiper('.slider-hero-banner-featured', {
	loop: true,
	slidesPerView: 1,
	spaceBetween: 0,
	centeredSlides: false,
	grabCursor: true,
	slidesPerGroupSkip: 1,
	watchSlidesProgress: true,
	breakpoints: {
		1024: {
			slidesPerView: 1,
		},
		768: {
			slidesPerView: 1,
		},
		480: {
			slidesPerView: 1,
		},
		320: {
			slidesPerView: 1,
		}
	},
	pagination: {
		el: '.swiper-pagination',
		clickable: true
	},
});