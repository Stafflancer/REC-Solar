<?php
/**
 * BLOCK: Postcard
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_element;
use function BopDesign\bopper\print_module;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'postcard-' . $block['id'],
	'class'    => [ 'acf-block', 'postcard', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative z-10',
		'align_text'     => 'text-start text-left',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'header',
	'content',
	'content_layout',
	'media',
	'contentgrp',
], $block['id'] );

if ( ! empty( $design_options['column_size'] ) ) :
	$column_size_class = 'inner-container-width cols-' . $design_options['column_size'] . '';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
] );
$row_class    = join( ' ', [
	'row justify-content-between',
] );
$column_class = join( ' ', [
	$column_size_class,
] );

if ( ! empty( $block_content['header'] ) || ! empty( $block_content['content'] ) || ! empty( $block_content['media'] ) || ! empty( $block_content['contentgrp'] )) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?> z-10 position-relative">
			<div class="row">
				<?php if ( array_key_exists( "main_heading", $block_content['header'] ) && ! empty( $block_content['header']['main_heading'] ) || ! empty( $block_content['content'] ) ) : ?>
					<div class="<?php echo esc_attr( $column_class ); ?> <?php if ( $block_content['header']["justification"] == 'center' ) {echo 'heading-center'; } else { echo 'heading-left'; } ?>">
						<div class="header-section-heading">
							<?php
							// Heading.
							if ( $block_content['header'] ) :
								$block_content['header']["level"] = 2;
								print_module( 'heading-tagline', [
									$block_content['header'],
								] );
							endif;
							?>
						</div>
						<?php
						// Content.
						if ( $block_content['content'] ) :
							print_element( 'content', [
								'content' => $block_content['content'],
							] );
						endif; ?>
					</div>
				<?php endif; ?>
				<div class="solarpower">
					<div class="align-items-center solarpowergrid <?php if ( $block_content['content_layout'] === 'text-media' ) { echo 'flex-row-reverse'; } ?>">
						<?php if ( ! empty( $block_content['media'] ) ) : ?>
							<div class="media-block">
								<?php
								$media_type = $block_content['media']['media_type'];
								$image      = $block_content['media']['image'];
								$video      = $block_content['media']['video'];

								if ( 'image' === $media_type ) {
									$image_class = 'img-top-way';
									?>
									<div class="side-by-side-media">
										<div class="grid-block">
											<div class="side-by-side-outer">
												<?php if ( ! empty( $image ) ) :
													echo wp_get_attachment_image( $image, 'medium_large', array( 'class' => esc_attr( $image_class ) ) );
												else :
													?>
													<img class="<?php echo esc_attr( $image_class ); ?>"
													     src="<?php echo get_theme_file_uri( '/assets/images/placeholder-square.jpg' ); ?>"
													     alt="Image Placeholder" width="764" height="764"
													     aria-hidden="true">
												<?php endif; ?>
											</div>
										</div>
									</div>
								<?php } else { ?>
									<?php if ( ! empty( $video ) ) : ?>
										<div class="side-by-side-video">
											<div class="side-by-side-wrapper">
												<?php
												print_module( 'video-settings', [
													$video,
												] );
												?>
											</div>
										</div>
									<?php endif; ?>
								<?php } ?>
							</div>
						<?php endif; ?>
						<?php if ( ! empty( $block_content['contentgrp'] ) ) : ?>
							<div class="content-block">
								<div class="text-box">
									<?php
									$heading         = $block_content['contentgrp']['header'];
									$excerpt_content = $block_content['contentgrp']['content'];
									$buttons         = $block_content['contentgrp']['buttons'];

									// Heading.
									if ( $heading ) :
										$heading["level"] = 1;
										print_module( 'heading-tagline', [
											$heading,
										] );
									endif;
									// Content.
									if ( $excerpt_content ) :
										print_element( 'content', [
											'content' => $excerpt_content,
										] );
									endif;
									// Buttons.
									if ( $buttons ) :
										$buttons['class'] = [ 'common-btn', 'mt-4' ];
										print_module( 'buttons-group', $buttons );
									endif;
									?>
								</div>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>