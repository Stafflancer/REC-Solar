<?php
/**
 * BLOCK: Featured Case Studies
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'featured-case-studies-' . $block['id'],
	'class'    => [ 'acf-block', 'featured-case-studies', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative',
		'align_text'     => 'text-start text-left',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'header',
	'content',
	'latest',
	'case_studies',
	'buttons',
], $block['id'] );

if ( ! empty( $design_options['column_size'] ) ) :
	$column_size_class = 'col-12 col-md-' . $design_options['column_size'] . ' col-sm-' . $design_options['column_size'] . '';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	'z-9',
] );

$row_class    = join( ' ', [
	'row ',
] );
$column_class = join( ' ', [
	$column_size_class,
] );

if ( $block_content['latest'] == 1 || ! empty( $block_content['header'] ) || ! empty( $block_content['content'] ) || ! empty( $block_content['case_studies'] ) || ! empty( $block_content['buttons'] ) ) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>"><?php
		 	if ( array_key_exists("main_heading",$block_content['header']) && !empty($block_content['header']['main_heading']) || !empty($block_content['content'])) : ?>
				<div class="<?php echo esc_attr( $row_class ); ?> justify-content-center">
					<div class="<?php echo esc_attr( $column_class ); ?>">
						<div class="section-header-outer <?php if($block_content['header']["justification"] == 'center') { echo 'heading-center'; } else { echo 'heading-left'; } ?>">
							<?php
							// Heading Elements
							if ( $block_content['header'] ) :
								$block_content['header']["level"] = 2;
								print_module( 'heading-tagline', [
									$block_content['header'],
								] );
							endif;
							// Content.
							if ( $block_content['content'] ) :
								print_element( 'content', [
									'content' => $block_content['content'],
								] );
							endif;
							?>
						</div>
					</div>
				</div>
			<?php endif; ?>

				<div class="<?php echo esc_attr( $row_class ); ?>">
					<div class="<?php echo esc_attr( $column_class ); ?>">
						<div class="section-header-after-sec">
							<div class="case-studies-content-box">
								<div class="case-studies-wrapper">
									<?php
									$latest_post = '';
									if ( $block_content['latest'] == 1 ) :
										$post  = array(
											'numberposts' => -1,
											'post_type'   => 'case-study',
											'orderby'     => 'date',
											'order'       => 'DESC',
										);
										$latest_post = get_posts( $post );
									else :
										$latest_post = $block_content['case_studies'];
									endif;

									foreach ( $latest_post as $post ):
										$image              = get_post_thumbnail_id( $post->ID );
										$case_study_logo    = get_field( 'case_study_logo', $post->ID );
										$case_study_color    = get_field( 'case_study_color', $post->ID );
										$case_study_details = get_field( 'case_study_details', $post->ID );
										$permalink = get_permalink( $post->ID );
        								$title = get_the_title( $post->ID );
        								$content = get_the_content( $post->ID );
										?>
										<div class="case-studies-box">
											<div class="case-studies-top">
												<?php if ( ! empty( $case_study_details ) ) : ?>
													<div class="case-studies-details color-<?php echo $case_study_color['color_picker'];?>">
														<?php
														foreach ( $case_study_details as $details ) :
															if ( ! empty( $details['label'] ) ) :
																?>
																<div class="case-studies-item">
																	<span class="info-label d-block text-uppercase"><?php echo $details['label']; ?></span>
																</div>
															<?php
															endif;
														endforeach;
														?>
													</div>
												<?php endif; ?>
												<figure class="slider-transparent-img">
													<?php
													if ( ! empty( $image ) ) :
														$image_class = 'case-study-image';
														?>
														<?php echo wp_get_attachment_image( $image, 'medium', array( 'class' => esc_attr( $image_class ) ) ); ?>
													<?php else: ?>
														<img class="<?php echo esc_attr( $image_class ); ?>"
														     src="<?php echo get_theme_file_uri( '/assets/images/placeholder-square.jpg' ); ?>"
														     alt="" width="764" height="764" aria-hidden="true">
													<?php endif; ?>
												</figure>
											</div>
											<div class="case-studies-bottom">
												<?php
												// Heading.
												if ( $title ) :
													print_element( 'heading', [
														'text'  => $title,
														'level' => 3,
														'class' => [ 'card-title', 'h4' ],
													] );
												endif;

												// Content.
												if ( $content ) :
													print_element( 'content', [
														'content' => get_the_excerpt($post->ID),
														'class'   => [ 'post-excerpt' ],
													] );
												endif;

												print_element( 'anchor', [
													'text'  => 'Read Case Study',
													'href'  => $permalink,
													'class' => 'acf-element acf-element-button has-background has-secondary-background-color has-color-black text-uppercase stretched-link',
												] );
												?>
											</div>
										</div>
									<?php endforeach; ?>
								</div>


							</div>
							<?php
							// Buttons.
							if ( $block_content['buttons'] ) :
								print_module( 'buttons-group', $block_content['buttons'] );
							endif;
							?>
						</div>
					</div>
				</div>

		</div>
	</section>
<?php endif; ?>