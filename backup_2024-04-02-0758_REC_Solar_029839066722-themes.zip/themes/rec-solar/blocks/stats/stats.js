jQuery(document).ready(function ($) {
	let a = 0;
	$(window).scroll(function () {
		let oTop = $('#stats_id').offset().top - window.innerHeight;
		if (0 === a && $(window).scrollTop() > oTop) {
			$('.count').each(function () {
				var number = $(this).text();
				var result = number.replace(/,/g, '');
				$(this).prop('Counter', 0).animate({
					Counter: result
				}, {
					duration: 1000,
					easing: 'swing',
					step: function (now) {
						var counternew = Math.ceil(now).toLocaleString('en');
						$(this).text(counternew);
					}
				});
			});
			a = 1;
		}
	});
});