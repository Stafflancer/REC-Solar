<?php
/**
 * BLOCK: Slider - Featured Case Studies
 *
 * @link    https://developer.wordpress.org/block-editor/
 *
 * @param array        $block      The block settings and attributes.
 * @param array        $content    The block inner HTML (empty).
 * @param bool         $is_preview True during AJAX preview.
 * @param (int|string) $post_id    The post ID this block is saved to.
 *
 * @package bopper
 */

use function BopDesign\bopper\get_acf_fields;
use function BopDesign\bopper\get_formatted_args;
use function BopDesign\bopper\setup_block_defaults;
use function BopDesign\bopper\print_design_options;
use function BopDesign\bopper\print_module;
use function BopDesign\bopper\print_element;

$block_args     = isset( $args ) ? $args : '';
$block_defaults = [
	'id'       => ! empty( $block['anchor'] ) ? $block['anchor'] : 'slider-featured-case-studies-' . $block['id'],
	'class'    => [ 'acf-block', 'slider-featured-case-studies', 'position-relative' ],
	'settings' => [
		'container_size' => 'container position-relative',
		'align_text'     => 'text-start text-left',
		'align_content'  => 'justify-content-center is-position-top-center',
		'column_size'    => 'col-12',
		'animation'      => '',
	],
	'fields'   => [], // Fields passed via the print_block() function.
];

// Returns updated $block_defaults array with classes from Gutenberg and Background Options, or from the print_block() function.
// Returns formatted attributes as $block_atts array, $container_atts array.
[ $block_defaults, $block_atts, $design_options ] = setup_block_defaults( $block_args, $block_defaults, $block );

// Pull in the fields from ACF, if we've not pulled them in using print_block().
$block_content = ! empty( $block_defaults['fields'] ) ? $block_defaults['fields'] : get_acf_fields( [
	'heading',
	'content',
	'case_studies',
	'buttons',
], $block['id'] );

if ( ! empty( $design_options['column_size'] ) ) :
	$column_size_class = 'col-12 col-md-' . $design_options['column_size'] . ' col-sm-' . $design_options['column_size'] . '';
endif;

$container_class = join( ' ', [
	$design_options['container_size'],
	'z-9',
] );

$row_class    = join( ' ', [
	'row ',
] );
$column_class = join( ' ', [
	$column_size_class,
] );

if ( ! empty( $block_content['heading'] ) || ! empty( $block_content['content'] ) || ! empty( $block_content['case_studies'] ) || ! empty( $block_content['buttons'] ) ) : ?>
	<section <?php echo $block_atts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>>
		<?php print_design_options( $design_options ); ?>
		<div class="<?php echo esc_attr( $container_class ); ?>"><?php
			if ( array_key_exists("main_heading",$block_content['heading']) && !empty($block_content['heading']['main_heading']) || !empty($block_content['content'])) : ?>
				<div class="<?php echo esc_attr( $row_class ); ?> justify-content-center">
					<div class="<?php echo esc_attr( $column_class ); ?>">
						<div class="section-header-outer <?php if($block_content['heading']["justification"] == 'center') { echo 'heading-center'; } else { echo 'heading-left'; } ?>">
							<?php
							// Heading Elements
							if ( $block_content['heading'] ) :
								$block_content['heading']["level"] = 2;
								print_module( 'heading-tagline', [
									$block_content['heading'],
								] );
							endif;
							// Content.
							if ( $block_content['content'] ) :
								print_element( 'content', [
									'content' => $block_content['content'],
								] );
							endif;
							?>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<?php
			if ( ! empty( $block_content['case_studies'] ) ) :
				?>
				<div class="<?php echo esc_attr( $row_class ); ?>">
					<div class="<?php echo esc_attr( $column_class ); ?>">
						<div class="section-header-after-sec">
							<div class="swiper slider-case-studies">
								<div class="swiper-wrapper">
									<?php
									foreach ( $block_content['case_studies'] as $post ):
										$image              = get_post_thumbnail_id( $post->ID );
										$case_study_logo    = get_field( 'case_study_logo', $post->ID );
										$case_study_details = get_field( 'case_study_details', $post->ID );
										$permalink = get_permalink( $post->ID );
        								$title = get_the_title( $post->ID );
        								$content = get_the_content( $post->ID );
										?>
										<div class="swiper-slide case-studies-box">
											<div class="case-studies-left">
												<?php
												$case_study_logo_class = 'logo';
												if ( ! empty( $case_study_logo ) ) :
													?>
													<div class="case-study-logo">
														<?php echo wp_get_attachment_image( $case_study_logo, 'medium', array( 'class' => esc_attr( $case_study_logo_class ) ) ); ?>
													</div>
												<?php endif; ?>
												<?php if ( ! empty( $case_study_details ) ) : ?>
													<div class="case-studies-details">
														<?php
														foreach ( $case_study_details as $details ) :
															if ( ! empty( $details['label'] ) ) :
																?>
																<div class="case-studies-item">
																	<span class="info-label d-block text-uppercase"><?php echo $details['label']; ?></span>
																</div>
															<?php
															endif;
														endforeach;
														?>
													</div>
												<?php endif; ?>
												<figure class="slider-transparent-img">
													<?php
													if ( ! empty( $image ) ) :
														$image_class = 'case-study-image';
														?>
														<?php echo wp_get_attachment_image( $image, 'medium', array( 'class' => esc_attr( $image_class ) ) ); ?>
													<?php else: ?>
														<img class="<?php echo esc_attr( $image_class ); ?>"
														     src="<?php echo get_theme_file_uri( '/assets/images/placeholder-square.jpg' ); ?>"
														     alt="" width="764" height="764" aria-hidden="true">
													<?php endif; ?>
												</figure>
											</div>
											<div class="case-studies-right">
												<?php
												// Heading.
												if ( $title ) :
													print_element( 'heading', [
														'text'  => $title,
														'level' => 3,
														'class' => [ 'card-title', 'h4' ],
													] );
												endif;

												// Content.
												if ( $content ) :
													print_element( 'content', [
														'content' => get_the_excerpt($post->ID),
														'class'   => [ 'post-excerpt', 'm-0' ],
													] );
												endif;

												print_element( 'anchor', [
													'text'  => 'READ CASE STUDY',
													'href'  => $permalink,
													'class' => 'acf-element acf-element-button has-background has-secondary-background-color has-color-black',
												] );
												?>
											</div>
										</div>
									<?php endforeach; ?>
								</div>
								<div class="swiper-pagination"></div>
							</div>
							<?php
							// Buttons.
							if ( $block_content['buttons'] ) :
								print_module( 'buttons-group', $block_content['buttons'] );
							endif;
							?>
						</div>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</section>
<?php endif; ?>