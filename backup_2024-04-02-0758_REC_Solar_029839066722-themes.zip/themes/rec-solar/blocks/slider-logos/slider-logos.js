var swiper = new Swiper(".slider-logos", {
    loop: false,
    slidesPerView: 6,
    spaceBetween: 25,
    watchSlidesProgress: true,
    breakpoints: {
      1366: {
        slidesPerView: 6,
      },
      1024: {
        slidesPerView: 4,
      },
      768: {
        slidesPerView: 3,
      },
      480: {
        slidesPerView: 2,
      },
      320: {
        slidesPerView: 1,
      }
    },
    navigation: {
      nextEl: '.logo-next',
      prevEl: '.logo-prev',
    },
    autoplay: {
        delay: 5500
    },
});