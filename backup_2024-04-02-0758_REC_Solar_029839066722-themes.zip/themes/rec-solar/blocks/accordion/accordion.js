jQuery(document).ready(function ($) {
	$('.faqs-panel-heading').first().addClass('open');
	$('.faqs-panel-content').first().show();
	$('.faqs-panel-heading').click(function (e) {
		var $panelHeading = $(this);
		var $panelContent = $panelHeading.next('.faqs-panel-content');

		if ($panelHeading.hasClass('open')) {
			$panelHeading.removeClass('open');
			$panelContent.slideUp();
		} else {
			$('.faqs-panel-heading').removeClass('open');
			$('.faqs-panel-content').slideUp();
			$panelHeading.addClass('open');
			$panelContent.slideDown();
		}
	});
});