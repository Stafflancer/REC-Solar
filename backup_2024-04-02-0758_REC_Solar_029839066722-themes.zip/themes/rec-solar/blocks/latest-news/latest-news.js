var swiper = new Swiper(".latest-news-slider", {
    loop: true,
    slidesPerView: 3,
    spaceBetween: 25,
    watchSlidesProgress: true,
    breakpoints: {
      1024: {
        slidesPerView: 3,
      },
      768: {
        slidesPerView: 2,
      },
      480: {
        slidesPerView: 1,
      },
      320: {
        slidesPerView: 1,
      }
    },
    navigation: {
      nextEl: '.next',
      prevEl: '.prev',
    },
});