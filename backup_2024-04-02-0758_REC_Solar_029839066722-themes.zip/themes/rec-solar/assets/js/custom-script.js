jQuery(document).ready(function ($) {
	$('.menu-item a').on('click', function (e) {
		$('.off-canvas-container').removeClass('is-visible');
		// Define variable of the clicked Â»aÂ« element (Â»thisÂ«) and get its href value.
		var href = $(this).attr('href');

		// Run a scroll animation to the position of the element which has the same id like the href value.
		$('html, body').animate({
			scrollTop: $(href).offset().top
		}, '800');

		// Prevent the browser from showing the attribute name of the clicked link in the address bar
		e.preventDefault();
	});

	jQuery('.header-bar-close').click(function () {
		jQuery('.header-top-bar').fadeOut(500);
	});

	jQuery('.menu-bar-mobile').click(function ($) {
		jQuery(this).toggleClass('open-menu');
		jQuery('.header-navigation-outer').slideToggle();
	});

	jQuery('.header-search-icon').click(function ($) {
		jQuery(this).toggleClass('open-search-menu');
		jQuery('.search-form').slideToggle();
	});

	// jQuery(".quick-links-main").hide();
	jQuery('.quick-links').click(function () {
		// jQuery(".quick-links").removeClass('kamal');
		$(this).toggleClass('open-buttons');
		jQuery('.quick-links-main').toggleClass('opened');
	});
});

function scrollNav() {
	jQuery('.quick-links-main-inner a').click(function ($) {
		jQuery('.active').removeClass('active');
		jQuery(this).addClass('active');

		jQuery('html, body').stop().animate({
			scrollTop: jQuery(jQuery(this).attr('href')).offset().top - 320
		}, 800);
		return false;
	});
}

scrollNav();

jQuery(function () {
	if (navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1) {
		jQuery('body').addClass('safari-mac');
	}
});